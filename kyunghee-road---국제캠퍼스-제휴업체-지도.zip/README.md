# 🦁 KYUNGHEE ROAD - 경희대학교 국제캠퍼스 제휴업체 지도 & AI 제휴봇

> **경희대학교 국제캠퍼스(용인/영통)** 학생들을 위한 실시간 제휴업체 지도, 학생증 할인 혜택 검색, 사다리 타기 랜덤 맛집 추천, 제휴 혜택 가계부 및 Google Gemini AI 기반 제휴봇 풀스택 웹 애플리케이션입니다.

---

## ✨ 주요 기능 (Key Features)

1. **🗺️ 실시간 인터랙티브 제휴 지도 (Leaflet & OpenStreetMap)**
   - 경희대 국제캠퍼스 정문(🏛️) 기준 실시간 거리(m) 및 위치 표시
   - 카테고리별 핀 필터링: 식당(🍽️), 주점(🍺), 카페(☕), 라이프/문화(💪)
   - 카카오맵 길찾기, 네이버 지도 검색 바로가기 연동

2. **🎲 오늘 뭐 먹지? (사다리 타기 랜덤 맛집 추천)**
   - 캔버스 기반 인터랙티브 사다리 타기 게임 애니메이션 & 축하 폭죽(Confetti) 효과
   - 카테고리별 매장 랜덤 사다리 구성 및 지도 연동

3. **🤖 경희대 맞춤형 AI 제휴봇 (Gemini 3.7 Flash)**
   - 메뉴, 인원(회식/혼밥), 목적(데이트/카공/가성비)에 따른 최적의 제휴 매장 추천
   - 모바일 학생증 제시 혜택 안내 및 자연어 대화

4. **💰 내 제휴 혜택 장부 (Savings Ledger)**
   - 제휴 할인으로 절약한 금액 기록 및 누적 절약액 실시간 계산 (`localStorage` 영구 보관)

5. **🏆 인기/할인율/거리별 랭킹 & 💌 제휴 희망 매장 건의함**
   - 학우들이 가장 많이 찾는 제휴 핫플 순위 제공
   - 총학생회 제휴 기획국 건의함 기능

---

## 🛠️ 기술 스택 (Tech Stack)

- **Frontend**: React 18, TypeScript, Tailwind CSS, Leaflet, Lucide React, Motion, Canvas-Confetti
- **Backend**: Node.js, Express, TSX, Google GenAI SDK (`@google/genai` - Gemini 3.7 Flash)
- **Build / Bundler**: Vite, ESBuild

---

## 🚀 로컬 실행 방법 (Getting Started)

### 1. 저장소 클론 및 패키지 설치
```bash
git clone https://github.com/<your-username>/kyunghee-road.git
cd kyunghee-road
npm install
```

### 2. 환경 변수 설정
`.env.example` 파일을 복사하여 `.env` 파일을 생성하고 Gemini API 키를 입력합니다 (선택 사항).
```bash
cp .env.example .env
```
```env
GEMINI_API_KEY=your_gemini_api_key_here
PORT=3000
```
*(※ `GEMINI_API_KEY`가 없어도 로컬 스마트 추천 폴백 엔진으로 정상 동작합니다.)*

### 3. 개발 서버 실행
```bash
npm run dev
```
브라우저에서 `http://localhost:3000`으로 접속합니다.

### 4. 프로덕션 빌드 및 실행
```bash
npm run build
npm start
```

---

## 📁 프로젝트 구조 (Directory Structure)

```
kyunghee-road/
├── public/
│   └── kyunghee_road_single.html  # 단독 실행 가능한 원파일 배포본
├── src/
│   ├── components/                # React UI 컴포넌트 모듈
│   │   ├── BottomDock.tsx         # 하단 도크 & 챗봇 FAB
│   │   ├── ChatbotModal.tsx       # AI 제휴봇 모달
│   │   ├── FeedbackModal.tsx      # 제휴 건의함 모달
│   │   ├── HeaderNav.tsx          # 상단 검색 및 네비게이션
│   │   ├── LadderGameModal.tsx    # 사다리 타기 게임 캔버스
│   │   ├── MapView.tsx            # Leaflet 지도 뷰어
│   │   ├── RankModal.tsx          # 랭킹 순위 모달
│   │   ├── SavingsCalculatorModal.tsx # 제휴 혜택 가계부
│   │   ├── StoreDetailModal.tsx   # 매장 상세 정보 모달
│   │   └── StoreListDrawer.tsx    # 모바일/사이드 매장 리스트
│   ├── data/
│   │   └── stores.ts              # 경희대 국제캠 제휴 매장 데이터
│   ├── types.ts                   # TypeScript 인터페이스 & 타입 정의
│   ├── App.tsx                    # 메인 React 애플리케이션
│   ├── main.tsx                   # React DOM 엔트리포인트
│   └── index.css                  # Tailwind CSS 글로벌 스타일
├── server.ts                      # Express 풀스택 백엔드 & Gemini API 라우터
├── kyunghee_road_single.html      # 무설치 단일 실행 파일
├── vite.config.ts                 # Vite 설정 파일
├── tsconfig.json                  # TypeScript 설정 파일
├── metadata.json                  # AI Studio 메타데이터
├── .env.example                   # 환경 변수 예시 파일
└── package.json                   # 의존성 및 실행 스크립트
```

---

## 💡 깃허브 업로드 가이드 (GitHub Push)

```bash
git init
git add .
git commit -m "feat: Initial commit for KYUNGHEE ROAD - KHU Partnership Map & AI Bot"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo-name>.git
git push -u origin main
```
