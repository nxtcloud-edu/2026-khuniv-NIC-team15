import express from 'express';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import { storesData } from './src/data/stores';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Gemini AI client initialization with telemetry header
  let ai: GoogleGenAI | null = null;
  if (process.env.GEMINI_API_KEY) {
    try {
      ai = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
    } catch (e) {
      console.warn('Failed to initialize GoogleGenAI with provided key:', e);
    }
  }

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
      storesCount: storesData.length,
    });
  });

  // Stores data endpoint
  app.get('/api/stores', (req, res) => {
    res.json({ stores: storesData });
  });

  // Gemini Chatbot Endpoint
  app.post('/api/chat', async (req, res) => {
    const { prompt, customApiKey } = req.body;

    if (!prompt || typeof prompt !== 'string') {
      res.status(400).json({ error: '유효한 질문을 입력해주세요.' });
      return;
    }

    // Determine active AI client (either server environment key or user-provided custom key)
    let activeAi = ai;
    if (customApiKey && typeof customApiKey === 'string') {
      try {
        activeAi = new GoogleGenAI({
          apiKey: customApiKey,
          httpOptions: {
            headers: {
              'User-Agent': 'aistudio-build',
            },
          },
        });
      } catch (e) {
        console.warn('Error with customApiKey:', e);
      }
    }

    if (activeAi) {
      try {
        const storeContext = storesData.map((s) => ({
          name: s.name,
          category: s.category,
          benefit: s.benefit,
          desc: s.desc,
          tags: s.tags,
          recommendedMenus: s.recommendedMenus,
          distanceFromGateMeters: s.distanceFromGateMeters,
        }));

        const systemInstruction = `너는 경희대학교 국제캠퍼스(수원/용인 서천) 총학생회 제휴 복지 전용 AI '제휴봇(KYUNGHEE ROAD 봇)'이야. 🦁
경희대 학우들이 식사, 모임, 카페, 술자리, 운동, 뷰티, 라이프스타일 제휴처를 찾을 때 가장 친절하고 실용적으로 답변해줘.

규칙:
1. 반드시 아래 제공된 [경희대 국제캠퍼스 공식 제휴처 DB]에 포함된 매장들 중에서 질문 의도에 가장 알맞은 1~3곳을 엄선해 추천해.
2. 매장을 추천할 때는 매장명(정확한 명칭), 위치/거리 특징, 대표 메뉴, 그리고 경희대 학생증 제시 시 받을 수 있는 '실제 제휴 혜택(할인/서비스)'을 돋보이게 설명해줘.
3. 매장명을 언급할 때는 반드시 매장명 그대로 표기해 (예: [키와마루아지 경희대점], [돈들집], [카페칸나 (Cafe Canna)]).
4. 말투는 경희대 학우에게 친근하고 신뢰감 있는 사자 마스코트 선배 어투(예: "안녕 학우야!", "~하면 좋아!")로 작성해.

[경희대 국제캠퍼스 공식 제휴처 DB]:
${JSON.stringify(storeContext, null, 2)}`;

        const response = await activeAi.models.generateContent({
          model: 'gemini-3.7-flash',
          contents: prompt,
          config: {
            systemInstruction,
            temperature: 0.7,
          },
        });

        const replyText = response.text || '추천 결과를 생성할 수 없습니다.';
        
        // Find stores mentioned in the response to pass back as quick links
        const matchedStoreNames = storesData
          .filter((s) => replyText.includes(s.name) || prompt.includes(s.name))
          .map((s) => s.name);

        res.json({
          reply: replyText,
          suggestedStoreNames: matchedStoreNames,
          source: 'gemini',
        });
        return;
      } catch (err: any) {
        console.error('Gemini API call error:', err);
        // Fall back to rule-based engine smoothly
      }
    }

    // Fallback rule-based recommendation
    const q = prompt.toLowerCase();
    let matched = storesData.filter((s) =>
      s.name.toLowerCase().includes(q) ||
      s.category.toLowerCase().includes(q) ||
      s.desc.toLowerCase().includes(q) ||
      (s.tags && s.tags.some((t) => t.toLowerCase().includes(q))) ||
      (s.recommendedMenus && s.recommendedMenus.some((m) => m.toLowerCase().includes(q)))
    );

    if (matched.length === 0) {
      if (q.includes('고기') || q.includes('삼겹') || q.includes('갈비') || q.includes('회식')) {
        matched = storesData.filter((s) => s.name.includes('돼지') || s.name.includes('갈비') || s.name.includes('돈들집') || s.name.includes('꾼돈'));
      } else if (q.includes('양식') || q.includes('파스타') || q.includes('피자') || q.includes('돈가스')) {
        matched = storesData.filter((s) => s.category.includes('양식') || s.name.includes('그로또') || s.name.includes('존앤진') || s.name.includes('뜨돈') || s.name.includes('요녀석'));
      } else if (q.includes('카페') || q.includes('디저트') || q.includes('커피') || q.includes('빵') || q.includes('카공')) {
        matched = storesData.filter((s) => s.type === 'cafe');
      } else if (q.includes('술') || q.includes('주점') || q.includes('포차') || q.includes('육회') || q.includes('칵테일') || q.includes('맥주')) {
        matched = storesData.filter((s) => s.type === 'pub');
      } else if (q.includes('운동') || q.includes('헬스') || q.includes('피티') || q.includes('사진') || q.includes('머리') || q.includes('미용실') || q.includes('클라이밍')) {
        matched = storesData.filter((s) => s.type === 'life');
      } else {
        matched = storesData.slice(0, 3);
      }
    }

    const top3 = matched.slice(0, 3);
    const replyLines = [
      `🦁 **경희대 제휴봇의 추천 결과입니다!**`,
      '',
      ...top3.map((s) => 
        `✨ **[${s.name}]** (${s.category})\n` +
        `• 📍 위치: 정문 기준 약 ${s.distanceFromGateMeters}m (${s.addr})\n` +
        `• 🎁 **제휴 혜택**: ${s.benefit.replace(/\n/g, ' / ')}\n` +
        `• 📝 특징: ${s.desc}\n`
      ),
      `💡 지도에서 매장명을 클릭하면 바로 위치와 길찾기 정보를 확인할 수 있어요!`
    ];

    res.json({
      reply: replyLines.join('\n'),
      suggestedStoreNames: top3.map((s) => s.name),
      source: 'rule-engine',
    });
  });

  // Single-file HTML Download Endpoint
  app.get('/api/download', (req, res) => {
    const filePath = path.join(process.cwd(), 'kyunghee_road_single.html');
    res.download(filePath, 'kyunghee_road_single.html', (err) => {
      if (err) {
        console.error('Download error:', err);
        res.status(500).send('파일 다운로드 중 오류가 발생했습니다.');
      }
    });
  });

  // Vite middleware in dev, static serving in prod
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`KYUNGHEE ROAD Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
