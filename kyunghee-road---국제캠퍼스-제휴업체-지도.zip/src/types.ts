export type StoreType = 'food' | 'pub' | 'cafe' | 'life';

export interface Store {
  id: string;
  name: string;
  type: StoreType;
  category: string;
  addr: string;
  lat: number;
  lng: number;
  desc: string;
  benefit: string;
  discountScore: number;
  img: string;
  phone?: string;
  openingHours?: string;
  distanceFromGateMeters?: number;
  tags?: string[];
  recommendedMenus?: string[];
  targetAudience?: string;
  rating?: number;
  reviewCount?: number;
}

export interface ChatMessage {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  timestamp: string;
  suggestedStoreNames?: string[];
}

export interface StudentFeedback {
  id: string;
  storeName: string;
  category: string;
  reason: string;
  likes: number;
  createdAt: string;
}

export interface SavingsLog {
  id: string;
  storeName: string;
  amount: number;
  date: string;
  memo?: string;
}
