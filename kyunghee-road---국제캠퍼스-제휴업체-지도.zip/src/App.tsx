import React, { useState, useEffect, useMemo } from 'react';
import { storesData, KHU_GATE_COORDS } from './data/stores';
import { Store, StoreType, SavingsLog } from './types';
import { HeaderNav } from './components/HeaderNav';
import { MapView } from './components/MapView';
import { LadderGameModal } from './components/LadderGameModal';
import { RankModal } from './components/RankModal';
import { ChatbotModal } from './components/ChatbotModal';
import { StoreDetailModal } from './components/StoreDetailModal';
import { FeedbackModal } from './components/FeedbackModal';
import { SavingsCalculatorModal } from './components/SavingsCalculatorModal';
import { StoreListDrawer } from './components/StoreListDrawer';
import { BottomDock } from './components/BottomDock';

const DEFAULT_SAVINGS_LOGS: SavingsLog[] = [
  {
    id: 'log-1',
    storeName: '돈들집',
    amount: 15000,
    date: '2026.08.26',
    memo: '주류 50% 할인 적용',
  },
  {
    id: 'log-2',
    storeName: '카페칸나 (Cafe Canna)',
    amount: 2500,
    date: '2026.08.27',
    memo: '음료 및 베이커리 세트 할인',
  },
  {
    id: 'log-3',
    storeName: '홍콩반점0410 수원영통점',
    amount: 5000,
    date: '2026.08.28',
    memo: '탕수육 포장 할인',
  },
  {
    id: 'log-4',
    storeName: '바른안경 경희대점',
    amount: 11000,
    date: '2026.08.28',
    memo: '안경테 30% 제휴 할인',
  },
];

export default function App() {
  const [stores, setStores] = useState<Store[]>(storesData);
  const [selectedCategory, setSelectedCategory] = useState<StoreType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStore, setSelectedStore] = useState<Store | null>(null);
  const [detailModalStore, setDetailModalStore] = useState<Store | null>(null);

  // Modals state
  const [isLadderOpen, setIsLadderOpen] = useState(false);
  const [isRankOpen, setIsRankOpen] = useState(false);
  const [rankTab, setRankTab] = useState<'popular' | 'discount' | 'distance'>('popular');
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);
  const [isSavingsOpen, setIsSavingsOpen] = useState(false);
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);
  const [isListView, setIsListView] = useState(false);

  // Map Triggers
  const [gateFocusTrigger, setGateFocusTrigger] = useState<number>(0);
  const [userCoords, setUserCoords] = useState<[number, number] | null>(null);

  // Savings Storage
  const [savingsLogs, setSavingsLogs] = useState<SavingsLog[]>(() => {
    const saved = localStorage.getItem('khu-savings-logs');
    return saved ? JSON.parse(saved) : DEFAULT_SAVINGS_LOGS;
  });

  const totalSavedAmount = useMemo(() => {
    return savingsLogs.reduce((acc, curr) => acc + curr.amount, 0);
  }, [savingsLogs]);

  const handleAddSavingsLog = (log: SavingsLog) => {
    const updated = [log, ...savingsLogs];
    setSavingsLogs(updated);
    localStorage.setItem('khu-savings-logs', JSON.stringify(updated));
  };

  const handleRemoveSavingsLog = (id: string) => {
    const updated = savingsLogs.filter((l) => l.id !== id);
    setSavingsLogs(updated);
    localStorage.setItem('khu-savings-logs', JSON.stringify(updated));
  };

  // Filtered stores
  const filteredStores = useMemo(() => {
    return stores.filter((store) => {
      const matchesCategory = selectedCategory === 'all' || store.type === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        store.name.toLowerCase().includes(q) ||
        store.category.toLowerCase().includes(q) ||
        store.benefit.toLowerCase().includes(q) ||
        (store.tags && store.tags.some((t) => t.toLowerCase().includes(q))) ||
        (store.recommendedMenus && store.recommendedMenus.some((m) => m.toLowerCase().includes(q)));

      return matchesCategory && matchesSearch;
    });
  }, [stores, selectedCategory, searchQuery]);

  const handleSelectStore = (store: Store) => {
    setSelectedStore(store);
  };

  const handleFocusGate = () => {
    setGateFocusTrigger((prev) => prev + 1);
  };

  const handleGetUserLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setUserCoords([pos.coords.latitude, pos.coords.longitude]);
        },
        (err) => {
          console.warn('Geolocation error:', err);
          alert('위치 정보를 불러올 수 없습니다. 브라우저 위치 권한을 확인해주세요.');
        }
      );
    }
  };

  const handleOpenRank = (mode: 'popular' | 'discount' | 'distance') => {
    setRankTab(mode);
    setIsRankOpen(true);
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden flex flex-col bg-stone-100 font-sans select-none">
      {/* Top Floating Navigation Header */}
      <HeaderNav
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        stores={stores}
        filteredStores={filteredStores}
        onSelectStore={handleSelectStore}
        onFocusGate={handleFocusGate}
        onOpenLadder={() => setIsLadderOpen(true)}
        onOpenRank={handleOpenRank}
        onOpenSavings={() => setIsSavingsOpen(true)}
        onOpenFeedback={() => setIsFeedbackOpen(true)}
        totalSavedAmount={totalSavedAmount}
        isListView={isListView}
        setIsListView={setIsListView}
        onGetUserLocation={handleGetUserLocation}
      />

      {/* Main Map View */}
      <MapView
        stores={stores}
        filteredStores={filteredStores}
        selectedStore={selectedStore}
        onSelectStore={handleSelectStore}
        onOpenStoreDetail={(store) => setDetailModalStore(store)}
        gateFocusTrigger={gateFocusTrigger}
        userCoords={userCoords}
      />

      {/* Bottom Action Dock & AI Chatbot Button */}
      <BottomDock
        onOpenRank={handleOpenRank}
        onOpenFeedback={() => setIsFeedbackOpen(true)}
        onOpenSavings={() => setIsSavingsOpen(true)}
        onToggleChatbot={() => setIsChatbotOpen((prev) => !prev)}
        isChatOpen={isChatbotOpen}
      />

      {/* Side / Mobile Store List Drawer */}
      <StoreListDrawer
        isOpen={isListView}
        onClose={() => setIsListView(false)}
        stores={filteredStores}
        onSelectStore={handleSelectStore}
        onOpenStoreDetail={(store) => setDetailModalStore(store)}
      />

      {/* Modal 1: 오늘 뭐 먹지? 사다리 타기 */}
      <LadderGameModal
        isOpen={isLadderOpen}
        onClose={() => setIsLadderOpen(false)}
        stores={stores}
        onSelectStoreOnMap={(store) => {
          handleSelectStore(store);
          setDetailModalStore(store);
        }}
      />

      {/* Modal 2: 제휴 순위 (인기순/할인순/가까운순) */}
      <RankModal
        isOpen={isRankOpen}
        onClose={() => setIsRankOpen(false)}
        stores={stores}
        initialTab={rankTab}
        onSelectStore={(store) => {
          handleSelectStore(store);
          setDetailModalStore(store);
        }}
      />

      {/* Modal 3: AI 제휴봇 */}
      <ChatbotModal
        isOpen={isChatbotOpen}
        onClose={() => setIsChatbotOpen(false)}
        stores={stores}
        onSelectStoreOnMap={(store) => {
          handleSelectStore(store);
          setDetailModalStore(store);
        }}
      />

      {/* Modal 4: 매장 상세 보기 모달 */}
      <StoreDetailModal
        store={detailModalStore}
        onClose={() => setDetailModalStore(null)}
        onLogSavings={(store) => {
          setDetailModalStore(null);
          setIsSavingsOpen(true);
        }}
      />

      {/* Modal 5: 제휴 희망 매장 건의함 */}
      <FeedbackModal
        isOpen={isFeedbackOpen}
        onClose={() => setIsFeedbackOpen(false)}
      />

      {/* Modal 6: 내 제휴 절약 장부 */}
      <SavingsCalculatorModal
        isOpen={isSavingsOpen}
        onClose={() => setIsSavingsOpen(false)}
        stores={stores}
        savingsLogs={savingsLogs}
        onAddSavingsLog={handleAddSavingsLog}
        onRemoveSavingsLog={handleRemoveSavingsLog}
      />
    </div>
  );
}
