import React, { useState } from 'react';
import { Store, SavingsLog } from '../types';
import { X, Plus, Trash2, Wallet, Sparkles, TrendingUp, Award } from 'lucide-react';

interface SavingsCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  stores: Store[];
  savingsLogs: SavingsLog[];
  onAddSavingsLog: (log: SavingsLog) => void;
  onRemoveSavingsLog: (id: string) => void;
}

export const SavingsCalculatorModal: React.FC<SavingsCalculatorModalProps> = ({
  isOpen,
  onClose,
  stores,
  savingsLogs,
  onAddSavingsLog,
  onRemoveSavingsLog,
}) => {
  const [selectedStoreName, setSelectedStoreName] = useState(stores[0]?.name || '');
  const [amount, setAmount] = useState('3000');
  const [memo, setMemo] = useState('음료 무료 및 할인 혜택');

  if (!isOpen) return null;

  const totalSaved = savingsLogs.reduce((acc, curr) => acc + curr.amount, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseInt(amount, 10);
    if (isNaN(numAmount) || numAmount <= 0) return;

    const newLog: SavingsLog = {
      id: `log-${Date.now()}`,
      storeName: selectedStoreName,
      amount: numAmount,
      date: new Date().toLocaleDateString('ko-KR'),
      memo: memo.trim() || '제휴 할인 적용',
    };

    onAddSavingsLog(newLog);
    setMemo('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl shadow-2xl border border-stone-200 max-w-md w-full overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="bg-[#8B1D24] text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Wallet className="w-5 h-5 text-yellow-300" />
            <div>
              <h3 className="font-extrabold text-base leading-tight">내 제휴 혜택 장부</h3>
              <p className="text-[11px] text-rose-200">경희대 학생증으로 아낀 금액 기록</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Total Summary Card */}
        <div className="p-4 bg-gradient-to-br from-rose-50 to-stone-50 border-b border-stone-200 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-stone-500">지금까지 내가 절약한 총 금액</span>
            <div className="text-2xl font-black text-[#8B1D24] tracking-tight mt-0.5">
              {totalSaved.toLocaleString()} <span className="text-sm font-bold text-stone-700">원</span>
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-[#8B1D24]/10 border border-[#8B1D24]/20 flex items-center justify-center text-xl">
            🦁
          </div>
        </div>

        {/* Add Record Form */}
        <form onSubmit={handleSubmit} className="p-3.5 bg-white border-b border-stone-200 space-y-2">
          <span className="text-xs font-bold text-stone-700">✨ 새로운 혜택 기록 추가</span>
          <div className="flex gap-2">
            <select
              value={selectedStoreName}
              onChange={(e) => setSelectedStoreName(e.target.value)}
              className="flex-1 bg-stone-100 border border-stone-300 text-xs px-2.5 py-2 rounded-xl outline-none font-medium"
            >
              {stores.map((s) => (
                <option key={s.id} value={s.name}>
                  {s.name}
                </option>
              ))}
            </select>
            <div className="relative w-28">
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="금액"
                required
                className="w-full bg-stone-100 border border-stone-300 text-xs px-2.5 py-2 pr-6 rounded-xl outline-none font-bold text-stone-900"
              />
              <span className="absolute right-2 top-2 text-[11px] text-stone-400 font-bold">원</span>
            </div>
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              value={memo}
              onChange={(e) => setMemo(e.target.value)}
              placeholder="메모 (예: 음료 무료 제공, 10% 할인)"
              className="flex-1 bg-stone-100 border border-stone-300 text-xs px-3 py-2 rounded-xl outline-none"
            />
            <button
              type="submit"
              className="bg-[#8B1D24] hover:bg-rose-900 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-sm transition-all cursor-pointer whitespace-nowrap"
            >
              기록하기
            </button>
          </div>
        </form>

        {/* Logs List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2 bg-stone-50">
          <div className="text-xs font-bold text-stone-500 px-1">기록 내역 ({savingsLogs.length}건)</div>
          {savingsLogs.length === 0 ? (
            <div className="text-center py-8 text-stone-400 text-xs font-medium">
              아직 기록된 내역이 없습니다.<br />제휴 매장을 방문하고 받은 혜택을 기록해보세요!
            </div>
          ) : (
            savingsLogs.map((log) => (
              <div
                key={log.id}
                className="bg-white p-3 rounded-2xl border border-stone-200 shadow-xs flex items-center justify-between"
              >
                <div>
                  <div className="font-extrabold text-xs text-stone-900">{log.storeName}</div>
                  <div className="text-[11px] text-stone-500 mt-0.5">{log.memo}</div>
                  <div className="text-[10px] text-stone-400 mt-0.5">{log.date}</div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-black text-[#8B1D24]">
                    +{log.amount.toLocaleString()}원
                  </span>
                  <button
                    onClick={() => onRemoveSavingsLog(log.id)}
                    className="p-1 text-stone-300 hover:text-stone-500 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
