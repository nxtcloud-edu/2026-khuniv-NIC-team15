import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { Store, StoreType } from '../types';
import { X, Sparkles, RefreshCw, MapPin, Trophy, Dice5 } from 'lucide-react';

interface LadderGameModalProps {
  isOpen: boolean;
  onClose: () => void;
  stores: Store[];
  onSelectStoreOnMap: (store: Store) => void;
}

interface LadderRung {
  fromCol: number;
  toCol: number;
  y: number;
}

export const LadderGameModal: React.FC<LadderGameModalProps> = ({
  isOpen,
  onClose,
  stores,
  onSelectStoreOnMap,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [selectedType, setSelectedType] = useState<StoreType | 'all'>('food');
  const [columnCount, setColumnCount] = useState<number>(4);
  const [candidateStores, setCandidateStores] = useState<Store[]>([]);
  const [ladderRungs, setLadderRungs] = useState<LadderRung[]>([]);
  const [selectedStartCol, setSelectedStartCol] = useState<number | null>(null);
  const [winnerStore, setWinnerStore] = useState<Store | null>(null);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('출발할 번호를 선택하거나 바로 시작하세요!');

  // Initialize and shuffle candidates when modal opens or filter changes
  useEffect(() => {
    if (!isOpen) return;
    initNewGame();
  }, [isOpen, selectedType, columnCount, stores]);

  const initNewGame = () => {
    setIsRunning(false);
    setWinnerStore(null);
    setSelectedStartCol(null);
    setStatusMessage('출발할 번호(1~4)를 선택하거나 아래 [사다리 타기 출발]을 누르세요!');

    const filtered =
      selectedType === 'all'
        ? stores
        : stores.filter((s) => s.type === selectedType);

    const shuffled = [...filtered].sort(() => Math.random() - 0.5);
    const chosen = shuffled.slice(0, columnCount);
    setCandidateStores(chosen);

    // Generate random horizontal rungs
    const canvas = canvasRef.current;
    if (!canvas) return;

    const topY = 45;
    const bottomY = canvas.height - 45;
    const rungs: LadderRung[] = [];

    for (let i = 0; i < columnCount - 1; i++) {
      const rungCount = 2 + Math.floor(Math.random() * 2);
      for (let j = 0; j < rungCount; j++) {
        const y = topY + 25 + Math.random() * (bottomY - topY - 50);
        rungs.push({ fromCol: i, toCol: i + 1, y });
      }
    }

    setLadderRungs(rungs);
    drawLadder(chosen, rungs, null);
  };

  const drawLadder = (
    storesList: Store[],
    rungs: LadderRung[],
    highlightPath: { x: number; y: number }[] | null
  ) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const cols = columnCount;
    const paddingX = 36;
    const stepX = (canvas.width - paddingX * 2) / (cols - 1);
    const topY = 45;
    const bottomY = canvas.height - 45;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Background gradient subtle
    ctx.fillStyle = '#fafaf9';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw Vertical Columns
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#d6d3d1';
    ctx.fillStyle = '#1c1917';
    ctx.font = 'bold 12px Pretendard, sans-serif';
    ctx.textAlign = 'center';

    for (let i = 0; i < cols; i++) {
      const x = paddingX + i * stepX;
      ctx.beginPath();
      ctx.moveTo(x, topY);
      ctx.lineTo(x, bottomY);
      ctx.stroke();

      // Top label
      ctx.fillStyle = '#8B1D24';
      ctx.font = 'bold 13px Pretendard, sans-serif';
      ctx.fillText(`${i + 1}번`, x, topY - 14);

      // Bottom Store Name
      if (storesList[i]) {
        ctx.fillStyle = '#292524';
        ctx.font = 'bold 11px Pretendard, sans-serif';
        const name = storesList[i].name;
        const displayName = name.length > 5 ? name.substring(0, 5) + '..' : name;
        ctx.fillText(displayName, x, bottomY + 22);
      }
    }

    // Draw Horizontal Rungs
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = '#a8a29e';
    rungs.forEach((r) => {
      const x1 = paddingX + r.fromCol * stepX;
      const x2 = paddingX + r.toCol * stepX;
      ctx.beginPath();
      ctx.moveTo(x1, r.y);
      ctx.lineTo(x2, r.y);
      ctx.stroke();
    });

    // Draw Path if any
    if (highlightPath && highlightPath.length > 1) {
      ctx.lineWidth = 4;
      ctx.strokeStyle = '#8B1D24';
      ctx.beginPath();
      ctx.moveTo(highlightPath[0].x, highlightPath[0].y);
      for (let i = 1; i < highlightPath.length; i++) {
        ctx.lineTo(highlightPath[i].x, highlightPath[i].y);
      }
      ctx.stroke();
    }
  };

  const startLadder = (customStart?: number) => {
    if (isRunning || candidateStores.length < columnCount) return;
    setIsRunning(true);
    setWinnerStore(null);

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const cols = columnCount;
    const paddingX = 36;
    const stepX = (canvas.width - paddingX * 2) / (cols - 1);
    const topY = 45;
    const bottomY = canvas.height - 45;

    const startCol = customStart !== undefined ? customStart : selectedStartCol !== null ? selectedStartCol : Math.floor(Math.random() * cols);
    setSelectedStartCol(startCol);
    setStatusMessage(`🏃 ${startCol + 1}번에서 출발하여 사다리를 타는 중...`);

    let currentCol = startCol;
    let currentX = paddingX + currentCol * stepX;
    let currentY = topY;

    const pathPoints: { x: number; y: number }[] = [{ x: currentX, y: currentY }];
    const sortedRungs = [...ladderRungs].sort((a, b) => a.y - b.y);

    while (currentY < bottomY) {
      const nextRung = sortedRungs.find(
        (r) => r.y > currentY && (r.fromCol === currentCol || r.toCol === currentCol)
      );

      if (nextRung) {
        currentY = nextRung.y;
        pathPoints.push({ x: currentX, y: currentY });

        if (nextRung.fromCol === currentCol) {
          currentCol = nextRung.toCol;
        } else {
          currentCol = nextRung.fromCol;
        }
        currentX = paddingX + currentCol * stepX;
        pathPoints.push({ x: currentX, y: currentY });
      } else {
        currentY = bottomY;
        pathPoints.push({ x: currentX, y: currentY });
      }
    }

    const winner = candidateStores[currentCol];

    // Animate the path point by point
    let ptIdx = 0;
    let progress = 0;
    const drawnPath: { x: number; y: number }[] = [pathPoints[0]];

    const animate = () => {
      if (ptIdx >= pathPoints.length - 1) {
        setWinnerStore(winner);
        setStatusMessage(`🎉 오늘 추천 제휴 맛집은 [${winner.name}] 입니다!`);
        setIsRunning(false);

        // Confetti celebration
        try {
          confetti({
            particleCount: 60,
            spread: 70,
            origin: { y: 0.6 },
          });
        } catch (e) {
          // ignore
        }
        return;
      }

      const p1 = pathPoints[ptIdx];
      const p2 = pathPoints[ptIdx + 1];

      const segX = p1.x + (p2.x - p1.x) * progress;
      const segY = p1.y + (p2.y - p1.y) * progress;

      drawnPath[drawnPath.length - 1] = { x: segX, y: segY };

      drawLadder(candidateStores, ladderRungs, [...drawnPath]);

      progress += 0.09;
      if (progress >= 1) {
        progress = 0;
        ptIdx++;
        drawnPath.push(pathPoints[ptIdx]);
      }
      requestAnimationFrame(animate);
    };

    animate();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl shadow-2xl border border-stone-200 max-w-md w-full overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="bg-[#8B1D24] text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Dice5 className="w-5 h-5 text-yellow-300" />
            <div>
              <h3 className="font-extrabold text-base leading-tight">오늘 뭐 먹지? 사다리 타기</h3>
              <p className="text-[11px] text-rose-200">경희대 제휴 맛집 랜덤 추천</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category & Shuffle Controls */}
        <div className="p-3.5 bg-stone-50 border-b border-stone-200 flex items-center justify-between gap-2 flex-wrap">
          <div className="flex gap-1">
            <button
              onClick={() => setSelectedType('food')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                selectedType === 'food'
                  ? 'bg-[#8B1D24] text-white shadow-sm'
                  : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
              }`}
            >
              🍽️ 식당
            </button>
            <button
              onClick={() => setSelectedType('cafe')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                selectedType === 'cafe'
                  ? 'bg-[#8B1D24] text-white shadow-sm'
                  : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
              }`}
            >
              ☕ 카페
            </button>
            <button
              onClick={() => setSelectedType('pub')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                selectedType === 'pub'
                  ? 'bg-[#8B1D24] text-white shadow-sm'
                  : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
              }`}
            >
              🍺 주점
            </button>
            <button
              onClick={() => setSelectedType('all')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                selectedType === 'all'
                  ? 'bg-[#8B1D24] text-white shadow-sm'
                  : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
              }`}
            >
              전체
            </button>
          </div>

          <button
            onClick={initNewGame}
            disabled={isRunning}
            className="flex items-center gap-1 text-xs font-bold text-stone-700 bg-white hover:bg-stone-100 border border-stone-200 px-2.5 py-1 rounded-lg shadow-sm transition-all cursor-pointer disabled:opacity-50"
            title="새로운 후보로 섞기"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>새로고침</span>
          </button>
        </div>

        {/* Canvas Area */}
        <div className="flex-1 flex flex-col items-center justify-center p-3 bg-white overflow-hidden">
          <canvas
            ref={canvasRef}
            width={340}
            height={300}
            className="rounded-2xl border border-stone-200 shadow-inner bg-stone-50"
          />

          {/* Quick Column Picker Buttons */}
          <div className="flex gap-2 mt-2.5">
            {[0, 1, 2, 3].map((colIdx) => (
              <button
                key={colIdx}
                disabled={isRunning}
                onClick={() => startLadder(colIdx)}
                className={`w-14 py-1 rounded-xl text-xs font-extrabold border transition-all cursor-pointer ${
                  selectedStartCol === colIdx
                    ? 'bg-[#8B1D24] text-white border-[#8B1D24] shadow-sm'
                    : 'bg-stone-100 text-stone-800 border-stone-300 hover:bg-rose-50 hover:border-rose-300'
                }`}
              >
                {colIdx + 1}번 출발
              </button>
            ))}
          </div>
        </div>

        {/* Winner Result Box & Actions */}
        <div className="p-4 bg-stone-50 border-t border-stone-200 flex flex-col gap-3">
          {winnerStore ? (
            <div className="bg-rose-50 border border-rose-200 rounded-2xl p-3.5 text-center flex flex-col items-center gap-1.5 animate-bounce-short">
              <div className="flex items-center gap-1 text-xs font-bold text-rose-800">
                <Trophy className="w-4 h-4 text-amber-500" />
                <span>오늘의 당첨 제휴 매장</span>
              </div>
              <h4 className="text-base font-black text-stone-900">{winnerStore.name}</h4>
              <p className="text-xs text-[#8B1D24] font-semibold">
                🎁 {winnerStore.benefit.split('\n')[0]}
              </p>
              <div className="flex gap-2 w-full mt-1.5">
                <button
                  onClick={() => {
                    onClose();
                    onSelectStoreOnMap(winnerStore);
                  }}
                  className="flex-1 bg-[#8B1D24] hover:bg-rose-900 text-white font-bold text-xs py-2 rounded-xl flex items-center justify-center gap-1 shadow-md transition-all cursor-pointer"
                >
                  <MapPin className="w-3.5 h-3.5" />
                  <span>지도에서 매장 보기</span>
                </button>
                <button
                  onClick={initNewGame}
                  className="px-3 bg-white border border-stone-300 text-stone-700 font-bold text-xs py-2 rounded-xl hover:bg-stone-100 transition-all cursor-pointer"
                >
                  다시하기
                </button>
              </div>
            </div>
          ) : (
            <div className="flex flex-col gap-2">
              <p className="text-xs text-center font-bold text-stone-600 min-h-[18px]">
                {statusMessage}
              </p>
              <button
                disabled={isRunning}
                onClick={() => startLadder()}
                className="w-full bg-[#8B1D24] hover:bg-rose-900 text-white font-extrabold text-sm py-2.5 rounded-xl shadow-md transition-all disabled:opacity-50 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Sparkles className="w-4 h-4" />
                <span>랜덤 사다리 타기 출발! 🚀</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
