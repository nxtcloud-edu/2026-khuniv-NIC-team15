import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { Store, StoreType } from '../types';
import { KHU_GATE_COORDS } from '../data/stores';
import { Compass, Plus, Minus, Navigation, Layers } from 'lucide-react';

interface MapViewProps {
  stores: Store[];
  filteredStores: Store[];
  selectedStore: Store | null;
  onSelectStore: (store: Store) => void;
  onOpenStoreDetail: (store: Store) => void;
  gateFocusTrigger: number;
  userCoords: [number, number] | null;
}

export const MapView: React.FC<MapViewProps> = ({
  stores,
  filteredStores,
  selectedStore,
  onSelectStore,
  onOpenStoreDetail,
  gateFocusTrigger,
  userCoords,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerGroupRef = useRef<L.LayerGroup | null>(null);
  const gateGroupRef = useRef<L.LayerGroup | null>(null);
  const userGroupRef = useRef<L.LayerGroup | null>(null);
  const storeMarkerMapRef = useRef<{ [id: string]: L.Marker }>({});

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center: KHU_GATE_COORDS,
      zoom: 15,
      zoomControl: false,
      attributionControl: false,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '© OpenStreetMap | KYUNGHEE ROAD',
    }).addTo(map);

    L.control
      .attribution({
        position: 'bottomright',
        prefix: '<span class="text-[10px] text-stone-400 font-medium">🦁 KYUNGHEE ROAD</span>',
      })
      .addTo(map);

    const markerGroup = L.layerGroup().addTo(map);
    const gateGroup = L.layerGroup().addTo(map);
    const userGroup = L.layerGroup().addTo(map);

    markerGroupRef.current = markerGroup;
    gateGroupRef.current = gateGroup;
    userGroupRef.current = userGroup;
    mapInstanceRef.current = map;

    // Render Gate Marker on init
    renderGateMarker(map, gateGroup);

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Function to render Gate marker
  const renderGateMarker = (map: L.Map, group: L.LayerGroup) => {
    group.clearLayers();

    const gateHtml = `
      <div class="relative flex items-center justify-center w-10 h-10 rounded-full bg-[#8B1D24] text-yellow-300 text-lg border-2 border-white shadow-xl shadow-rose-950/40">
        <div class="absolute inset-0 rounded-full border-2 border-[#8B1D24] animate-ping opacity-75"></div>
        <span>🏛️</span>
      </div>
    `;

    const gateIcon = L.divIcon({
      html: gateHtml,
      className: '',
      iconSize: [40, 40],
      iconAnchor: [20, 20],
      popupAnchor: [0, -20],
    });

    const gateMarker = L.marker(KHU_GATE_COORDS, { icon: gateIcon });
    gateMarker.bindPopup(`
      <div class="p-3 text-center min-w-[200px]">
        <div class="inline-flex items-center gap-1 bg-rose-50 text-[#8B1D24] text-[10px] font-bold px-2 py-0.5 rounded-full mb-1">
          <span>🏛️ CAMPUS GATE</span>
        </div>
        <h3 class="text-sm font-extrabold text-stone-900 mb-1">경희대학교 국제캠퍼스 정문</h3>
        <p class="text-xs text-stone-500 mb-2">모든 제휴 매장 거리의 중심 기준점입니다.</p>
        <div class="text-[11px] text-stone-600 bg-stone-50 p-2 rounded-lg border border-stone-200">
          📍 경기 용인시 기흥구 덕영대로 1732
        </div>
      </div>
    `);

    gateMarker.addTo(group);
  };

  // Render store markers whenever filteredStores changes
  useEffect(() => {
    const map = mapInstanceRef.current;
    const group = markerGroupRef.current;
    if (!map || !group) return;

    group.clearLayers();
    storeMarkerMapRef.current = {};

    filteredStores.forEach((store) => {
      let pinColor = 'bg-[#8B1D24] text-white';
      let iconEmoji = '🍽️';

      if (store.type === 'cafe') {
        pinColor = 'bg-[#5C3D2E] text-white';
        iconEmoji = '☕';
      } else if (store.type === 'pub') {
        pinColor = 'bg-[#1E3A8A] text-white';
        iconEmoji = '🍺';
      } else if (store.type === 'life') {
        pinColor = 'bg-[#15803D] text-white';
        iconEmoji = '💪';
      }

      const iconHtml = `
        <div class="group relative flex items-center justify-center w-8 h-8 rounded-full ${pinColor} border-2 border-white shadow-md transition-transform duration-200 hover:scale-125 cursor-pointer">
          <span class="text-xs leading-none select-none">${iconEmoji}</span>
        </div>
      `;

      const customIcon = L.divIcon({
        html: iconHtml,
        className: '',
        iconSize: [32, 32],
        iconAnchor: [16, 16],
        popupAnchor: [0, -16],
      });

      const marker = L.marker([store.lat, store.lng], { icon: customIcon });

      marker.bindTooltip(
        `<div class="font-bold text-xs flex items-center gap-1"><span>${iconEmoji}</span><span>${store.name}</span></div>`,
        {
          direction: 'top',
          className: 'custom-leaflet-tooltip',
          offset: [0, -14],
        }
      );

      const popupHtml = document.createElement('div');
      popupHtml.className = 'w-[280px] overflow-hidden rounded-2xl bg-white shadow-2xl';
      popupHtml.innerHTML = `
        <div class="relative h-32 w-full bg-stone-200 overflow-hidden">
          <img 
            src="${store.img}" 
            alt="${store.name}" 
            class="w-full h-full object-cover"
            onerror="this.src='https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop&q=80'"
          />
          <div class="absolute top-2 left-2 bg-yellow-400 text-stone-900 font-extrabold text-[10px] px-2 py-0.5 rounded-full shadow">
            KHU 제휴
          </div>
          <div class="absolute bottom-2 right-2 bg-black/70 backdrop-blur text-white text-[10px] font-medium px-2 py-0.5 rounded-full">
            정문 ${store.distanceFromGateMeters}m
          </div>
        </div>
        <div class="p-3.5 flex flex-col gap-2">
          <div>
            <div class="flex items-center justify-between">
              <h4 class="font-black text-sm text-stone-900 leading-snug">${store.name}</h4>
              <span class="text-[10px] font-bold text-stone-500 bg-stone-100 px-1.5 py-0.5 rounded">
                ${store.category.split('/')[0]}
              </span>
            </div>
            <p class="text-[11px] text-stone-500 line-clamp-1 mt-0.5">📍 ${store.addr}</p>
          </div>

          <div class="bg-rose-50/80 border border-rose-200/70 p-2.5 rounded-xl text-[11px] text-[#8B1D24] font-semibold leading-relaxed whitespace-pre-line">
            <div class="flex items-center gap-1 font-bold text-[11.5px] text-rose-900 mb-0.5">
              <span>🎁 제휴 혜택</span>
            </div>
            ${store.benefit}
          </div>

          <div class="flex gap-1.5 pt-1">
            <a 
              href="https://map.kakao.com/link/to/${encodeURIComponent(store.name)},${store.lat},${store.lng}" 
              target="_blank" 
              rel="noopener noreferrer"
              class="flex-1 bg-yellow-400 hover:bg-yellow-500 text-stone-900 font-bold text-[11px] py-1.5 rounded-xl text-center shadow-sm transition-colors"
            >
              카카오길찾기
            </a>
            <a 
              href="https://map.naver.com/p/search/${encodeURIComponent(store.name)}" 
              target="_blank" 
              rel="noopener noreferrer"
              class="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] py-1.5 rounded-xl text-center shadow-sm transition-colors"
            >
              네이버지도
            </a>
            <button 
              id="btn-detail-${store.id}" 
              class="flex-1 bg-[#8B1D24] hover:bg-rose-900 text-white font-bold text-[11px] py-1.5 rounded-xl text-center shadow-sm transition-colors cursor-pointer"
            >
              상세보기
            </button>
          </div>
        </div>
      `;

      // Attach listener for '상세보기'
      const detailBtn = popupHtml.querySelector(`#btn-detail-${store.id}`);
      if (detailBtn) {
        detailBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          onOpenStoreDetail(store);
        });
      }

      marker.bindPopup(popupHtml, {
        maxWidth: 300,
        className: 'custom-leaflet-popup',
      });

      marker.on('click', () => {
        onSelectStore(store);
      });

      marker.addTo(group);
      storeMarkerMapRef.current[store.id] = marker;
    });
  }, [filteredStores, onSelectStore, onOpenStoreDetail]);

  // Handle selectedStore changes (fly to marker and open popup)
  useEffect(() => {
    if (!selectedStore || !mapInstanceRef.current) return;
    const marker = storeMarkerMapRef.current[selectedStore.id];
    if (marker) {
      mapInstanceRef.current.flyTo([selectedStore.lat, selectedStore.lng], 17, {
        duration: 0.8,
      });
      setTimeout(() => {
        marker.openPopup();
      }, 750);
    }
  }, [selectedStore]);

  // Handle Gate Focus trigger
  useEffect(() => {
    if (gateFocusTrigger === 0 || !mapInstanceRef.current || !gateGroupRef.current) return;
    const map = mapInstanceRef.current;
    map.flyTo(KHU_GATE_COORDS, 17, { duration: 1.0 });

    // Re-render and open gate popup
    const layers = gateGroupRef.current.getLayers();
    if (layers.length > 0) {
      const gateMarker = layers[0] as L.Marker;
      setTimeout(() => {
        gateMarker.openPopup();
      }, 900);
    }
  }, [gateFocusTrigger]);

  // Handle User Location
  useEffect(() => {
    if (!userCoords || !mapInstanceRef.current || !userGroupRef.current) return;
    const map = mapInstanceRef.current;
    const group = userGroupRef.current;
    group.clearLayers();

    const userHtml = `
      <div class="relative flex items-center justify-center w-8 h-8 rounded-full bg-blue-600 text-white border-2 border-white shadow-lg">
        <div class="absolute inset-0 rounded-full border-2 border-blue-500 animate-ping"></div>
        <span class="text-xs">👤</span>
      </div>
    `;

    const userIcon = L.divIcon({
      html: userHtml,
      className: '',
      iconSize: [32, 32],
      iconAnchor: [16, 16],
    });

    const userMarker = L.marker(userCoords, { icon: userIcon });
    userMarker.bindPopup('<div class="p-2 font-bold text-xs">📍 현재 나의 위치</div>');
    userMarker.addTo(group);

    map.flyTo(userCoords, 16, { duration: 1.0 });
  }, [userCoords]);

  return (
    <div className="relative w-full h-full flex-1">
      <div ref={mapContainerRef} className="w-full h-full z-0" />

      {/* Map Control Buttons (Floating on Right Side) */}
      <div className="absolute right-3.5 top-20 z-30 flex flex-col gap-1.5">
        <button
          id="btn-zoom-in"
          onClick={() => mapInstanceRef.current?.zoomIn()}
          className="w-9 h-9 bg-white/95 backdrop-blur-md rounded-xl shadow-md border border-stone-200 flex items-center justify-center text-stone-700 hover:text-stone-950 hover:bg-stone-50 active:scale-95 transition-all cursor-pointer"
          title="확대"
        >
          <Plus className="w-4 h-4" />
        </button>
        <button
          id="btn-zoom-out"
          onClick={() => mapInstanceRef.current?.zoomOut()}
          className="w-9 h-9 bg-white/95 backdrop-blur-md rounded-xl shadow-md border border-stone-200 flex items-center justify-center text-stone-700 hover:text-stone-950 hover:bg-stone-50 active:scale-95 transition-all cursor-pointer"
          title="축소"
        >
          <Minus className="w-4 h-4" />
        </button>
        <button
          id="btn-reset-center"
          onClick={() => mapInstanceRef.current?.flyTo(KHU_GATE_COORDS, 15, { duration: 0.8 })}
          className="w-9 h-9 bg-white/95 backdrop-blur-md rounded-xl shadow-md border border-stone-200 flex items-center justify-center text-rose-800 hover:bg-rose-50 active:scale-95 transition-all cursor-pointer font-bold text-sm"
          title="경희대 중심으로 복귀"
        >
          🦁
        </button>
      </div>
    </div>
  );
};
