import React, { useState } from 'react';
import { StudentFeedback } from '../types';
import { X, Heart, MessageSquarePlus, Send, Sparkles } from 'lucide-react';

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const DEFAULT_WISHLIST: StudentFeedback[] = [
  {
    id: 'feed-1',
    storeName: '신전떡볶이 영통점',
    category: '분식',
    reason: '시험기간에 떡볶이 먹고 힘낼 수 있게 쿨피스 무료 제휴 맺어주세요!',
    likes: 42,
    createdAt: '2026.08.20',
  },
  {
    id: 'feed-2',
    storeName: '샐러디 영통역점',
    category: '샐러드/포케',
    reason: '다이어트 및 식단관리하는 학우들을 위해 토핑 추가 할인 원해요!',
    likes: 38,
    createdAt: '2026.08.22',
  },
  {
    id: 'feed-3',
    storeName: '메가커피 영통경희대점',
    category: '카페/음료',
    reason: '등교길 아메리카노 테이크아웃 300원 할인 제휴 희망합니다.',
    likes: 65,
    createdAt: '2026.08.25',
  },
];

export const FeedbackModal: React.FC<FeedbackModalProps> = ({ isOpen, onClose }) => {
  const [feedbacks, setFeedbacks] = useState<StudentFeedback[]>(() => {
    const saved = localStorage.getItem('khu-feedbacks');
    return saved ? JSON.parse(saved) : DEFAULT_WISHLIST;
  });

  const [storeName, setStoreName] = useState('');
  const [category, setCategory] = useState('식당/음식점');
  const [reason, setReason] = useState('');
  const [likedMap, setLikedMap] = useState<{ [id: string]: boolean }>({});

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!storeName.trim() || !reason.trim()) return;

    const newFeedback: StudentFeedback = {
      id: `feed-${Date.now()}`,
      storeName: storeName.trim(),
      category,
      reason: reason.trim(),
      likes: 1,
      createdAt: new Date().toLocaleDateString('ko-KR'),
    };

    const updated = [newFeedback, ...feedbacks];
    setFeedbacks(updated);
    localStorage.setItem('khu-feedbacks', JSON.stringify(updated));

    setStoreName('');
    setReason('');
  };

  const handleToggleLike = (id: string) => {
    const isLiked = likedMap[id];
    const updated = feedbacks.map((f) => {
      if (f.id === id) {
        return {
          ...f,
          likes: isLiked ? f.likes - 1 : f.likes + 1,
        };
      }
      return f;
    });

    setFeedbacks(updated);
    setLikedMap((prev) => ({ ...prev, [id]: !isLiked }));
    localStorage.setItem('khu-feedbacks', JSON.stringify(updated));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl shadow-2xl border border-stone-200 max-w-md w-full overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="bg-[#8B1D24] text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xl">💌</span>
            <div>
              <h3 className="font-extrabold text-base leading-tight">제휴 희망 매장 건의함</h3>
              <p className="text-[11px] text-rose-200">총학생회 제휴 기획국에 직접 전달됩니다</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form to submit */}
        <form onSubmit={handleSubmit} className="p-4 bg-stone-50 border-b border-stone-200 space-y-2.5">
          <div className="flex gap-2">
            <input
              type="text"
              value={storeName}
              onChange={(e) => setStoreName(e.target.value)}
              placeholder="희망 매장명 (예: 신전떡볶이)"
              required
              className="flex-1 bg-white border border-stone-300 focus:border-[#8B1D24] text-xs px-3 py-2 rounded-xl outline-none"
            />
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="bg-white border border-stone-300 text-xs px-2 py-2 rounded-xl outline-none text-stone-700 font-medium"
            >
              <option value="식당/음식점">식당</option>
              <option value="카페/디저트">카페</option>
              <option value="주점/술집">주점</option>
              <option value="운동/헬스">운동</option>
              <option value="뷰티/라이프">라이프</option>
            </select>
          </div>

          <textarea
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="제휴를 희망하는 이유나 원하는 혜택 (예: 음료 무료, 10% 할인 등)을 적어주세요."
            required
            rows={2}
            className="w-full bg-white border border-stone-300 focus:border-[#8B1D24] text-xs p-3 rounded-xl outline-none resize-none"
          />

          <button
            type="submit"
            disabled={!storeName.trim() || !reason.trim()}
            className="w-full bg-[#8B1D24] hover:bg-rose-900 disabled:opacity-40 text-white text-xs font-extrabold py-2.5 rounded-xl shadow-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>제휴 건의 등록하기</span>
          </button>
        </form>

        {/* Existing Wishlist */}
        <div className="flex-1 overflow-y-auto p-3.5 space-y-2.5 bg-stone-100/60">
          <div className="flex items-center justify-between text-xs font-bold text-stone-600 px-1">
            <span>🦁 학우들의 제휴 희망 위시리스트</span>
            <span>{feedbacks.length}건</span>
          </div>

          {feedbacks.map((item) => (
            <div
              key={item.id}
              className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-sm flex flex-col gap-1.5"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-xs text-stone-900">{item.storeName}</span>
                  <span className="text-[10px] text-stone-500 bg-stone-100 px-1.5 py-0.5 rounded font-medium">
                    {item.category}
                  </span>
                </div>
                <span className="text-[10px] text-stone-400">{item.createdAt}</span>
              </div>

              <p className="text-xs text-stone-600 font-medium leading-relaxed bg-stone-50 p-2 rounded-xl">
                {item.reason}
              </p>

              <div className="flex justify-end pt-1">
                <button
                  type="button"
                  onClick={() => handleToggleLike(item.id)}
                  className={`flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-xl transition-all cursor-pointer ${
                    likedMap[item.id]
                      ? 'bg-rose-50 text-[#8B1D24] border border-rose-200'
                      : 'bg-stone-50 text-stone-500 hover:bg-stone-100 border border-stone-200'
                  }`}
                >
                  <Heart
                    className={`w-3.5 h-3.5 ${
                      likedMap[item.id] ? 'fill-[#8B1D24] text-[#8B1D24]' : 'text-stone-400'
                    }`}
                  />
                  <span>공감 {item.likes}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
