import React from 'react';
import { Store } from '../types';
import { X, Star, MapPin, ChevronRight, Gift } from 'lucide-react';

interface StoreListDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  stores: Store[];
  onSelectStore: (store: Store) => void;
  onOpenStoreDetail: (store: Store) => void;
}

export const StoreListDrawer: React.FC<StoreListDrawerProps> = ({
  isOpen,
  onClose,
  stores,
  onSelectStore,
  onOpenStoreDetail,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 sm:inset-y-0 sm:left-0 sm:right-auto sm:w-96 z-40 bg-white shadow-2xl flex flex-col border-r border-stone-200 animate-slideRight">
      {/* Header */}
      <div className="bg-[#8B1D24] text-white p-4 flex items-center justify-between">
        <div>
          <h3 className="font-extrabold text-sm">제휴 매장 목록</h3>
          <p className="text-xs text-rose-200">총 {stores.length}개의 제휴처</p>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Store Items List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2 bg-stone-50">
        {stores.map((store) => (
          <div
            key={store.id}
            onClick={() => {
              onSelectStore(store);
              onClose();
            }}
            className="bg-white hover:bg-rose-50/60 p-3 rounded-2xl border border-stone-200 shadow-2xs cursor-pointer transition-all flex gap-3 group"
          >
            <div className="w-16 h-16 rounded-xl bg-stone-200 overflow-hidden shrink-0">
              <img
                src={store.img}
                alt={store.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop&q=80';
                }}
              />
            </div>

            <div className="flex-1 min-w-0 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <h4 className="font-extrabold text-xs text-stone-900 truncate">{store.name}</h4>
                  <span className="text-[10px] text-stone-500 bg-stone-100 px-1.5 py-0.2 rounded shrink-0">
                    {store.category.split('/')[0]}
                  </span>
                </div>
                <div className="text-[11px] font-bold text-[#8B1D24] truncate mt-0.5">
                  🎁 {store.benefit.split('\n')[0]}
                </div>
              </div>

              <div className="flex items-center justify-between text-[10.5px] text-stone-400 mt-1">
                <span>정문 {store.distanceFromGateMeters}m</span>
                <span className="text-[#8B1D24] font-semibold flex items-center gap-0.5">
                  <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                  {store.rating || 4.8}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
