import React, { useState } from 'react';
import { Store } from '../types';
import { X, MapPin, Phone, Clock, Gift, ExternalLink, Share2, Star, ThumbsUp, MessageSquare, Check, Sparkles, Navigation } from 'lucide-react';

interface StoreDetailModalProps {
  store: Store | null;
  onClose: () => void;
  onLogSavings: (store: Store) => void;
}

export const StoreDetailModal: React.FC<StoreDetailModalProps> = ({
  store,
  onClose,
  onLogSavings,
}) => {
  const [copied, setCopied] = useState(false);
  const [studentTips, setStudentTips] = useState<string[]>(() => {
    if (!store) return [];
    const saved = localStorage.getItem(`tips-${store.id}`);
    return saved ? JSON.parse(saved) : [
      '학생증(모바일 신분증) 꼭 챙겨가세요!',
      '사장님 친절하시고 양 푸짐하게 주십니다 👍'
    ];
  });
  const [newTip, setNewTip] = useState('');

  if (!store) return null;

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(store.addr);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleAddTip = () => {
    if (!newTip.trim()) return;
    const updated = [newTip.trim(), ...studentTips];
    setStudentTips(updated);
    localStorage.setItem(`tips-${store.id}`, JSON.stringify(updated));
    setNewTip('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl shadow-2xl border border-stone-200 max-w-lg w-full overflow-hidden flex flex-col max-h-[90vh]">
        {/* Banner Image with Close Button */}
        <div className="relative h-48 sm:h-56 w-full bg-stone-900 overflow-hidden shrink-0">
          <img
            src={store.img}
            alt={store.name}
            className="w-full h-full object-cover opacity-90"
            onError={(e) => {
              (e.target as HTMLImageElement).src =
                'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop&q=80';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

          {/* Top badges */}
          <div className="absolute top-3.5 left-3.5 flex gap-1.5">
            <span className="bg-[#8B1D24] text-white text-xs font-black px-2.5 py-1 rounded-full shadow-md">
              KHU 제휴 파트너
            </span>
            <span className="bg-yellow-400 text-stone-950 text-xs font-black px-2.5 py-1 rounded-full shadow-md">
              할인지수 {store.discountScore}점
            </span>
          </div>

          <button
            onClick={onClose}
            className="absolute top-3.5 right-3.5 p-2 rounded-full bg-black/50 hover:bg-black/80 text-white backdrop-blur transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Bottom title info over image */}
          <div className="absolute bottom-3.5 left-4 right-4 text-white">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-rose-200 bg-white/20 backdrop-blur px-2 py-0.5 rounded-md">
                {store.category}
              </span>
              <span className="text-xs text-stone-300 font-medium">
                🏛️ 정문 {store.distanceFromGateMeters}m
              </span>
            </div>
            <h2 className="text-xl font-black mt-1 leading-tight text-white">{store.name}</h2>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 bg-stone-50">
          {/* Main Benefit Card */}
          <div className="bg-white border-2 border-rose-200/80 rounded-2xl p-4 shadow-sm">
            <div className="flex items-center gap-1.5 text-xs font-extrabold text-[#8B1D24] mb-1.5">
              <Gift className="w-4 h-4 text-[#8B1D24]" />
              <span>경희대학교 학생 전용 제휴 혜택</span>
            </div>
            <div className="text-xs sm:text-sm font-bold text-stone-900 whitespace-pre-line leading-relaxed bg-rose-50/70 p-3 rounded-xl border border-rose-100">
              {store.benefit}
            </div>
            <div className="mt-2.5 flex items-center justify-between">
              <span className="text-[11px] text-stone-500 font-medium">
                * 주문/결제 시 모바일 학생증 제시 필수
              </span>
              <button
                onClick={() => onLogSavings(store)}
                className="bg-[#8B1D24] hover:bg-rose-900 text-white text-[11px] font-bold px-3 py-1.5 rounded-lg shadow-sm transition-colors cursor-pointer flex items-center gap-1"
              >
                <span>💰 절약 장부에 기록</span>
              </button>
            </div>
          </div>

          {/* Store Info Details */}
          <div className="bg-white rounded-2xl p-4 border border-stone-200 space-y-2.5 text-xs">
            <div className="flex items-start gap-2.5">
              <MapPin className="w-4 h-4 text-stone-400 mt-0.5 shrink-0" />
              <div className="flex-1">
                <div className="font-semibold text-stone-800">{store.addr}</div>
              </div>
              <button
                onClick={handleCopyAddress}
                className="text-[11px] font-bold text-[#8B1D24] hover:underline flex items-center gap-0.5 shrink-0"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-600" /> : null}
                <span>{copied ? '복사됨' : '주소복사'}</span>
              </button>
            </div>

            {store.phone && (
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-stone-400 shrink-0" />
                <a
                  href={`tel:${store.phone}`}
                  className="font-semibold text-stone-800 hover:text-[#8B1D24] hover:underline"
                >
                  {store.phone}
                </a>
              </div>
            )}

            {store.openingHours && (
              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-stone-400 shrink-0" />
                <span className="text-stone-600 font-medium">{store.openingHours}</span>
              </div>
            )}

            <div className="pt-2 border-t border-stone-100 text-stone-600 leading-relaxed font-medium">
              {store.desc}
            </div>
          </div>

          {/* Recommended Menus / Highlights */}
          {store.recommendedMenus && store.recommendedMenus.length > 0 && (
            <div className="bg-white rounded-2xl p-4 border border-stone-200">
              <h4 className="font-extrabold text-xs text-stone-900 mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>대표 인기 메뉴 / 추천 코스</span>
              </h4>
              <div className="flex flex-wrap gap-1.5">
                {store.recommendedMenus.map((menu, i) => (
                  <span
                    key={i}
                    className="bg-stone-100 text-stone-800 font-bold text-xs px-2.5 py-1 rounded-xl border border-stone-200/80"
                  >
                    🍴 {menu}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Student Tips & Reviews */}
          <div className="bg-white rounded-2xl p-4 border border-stone-200">
            <h4 className="font-extrabold text-xs text-stone-900 mb-2 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-rose-700" />
                <span>경희대 학우 방문 꿀팁 & 후기</span>
              </span>
              <span className="text-[11px] text-stone-500 font-normal">
                {studentTips.length}개 팁
              </span>
            </h4>

            <div className="space-y-1.5 max-h-36 overflow-y-auto mb-3">
              {studentTips.map((tip, i) => (
                <div
                  key={i}
                  className="bg-stone-50 p-2.5 rounded-xl text-xs text-stone-700 font-medium flex items-start gap-2 border border-stone-100"
                >
                  <span className="text-rose-800 font-bold shrink-0">💡</span>
                  <span>{tip}</span>
                </div>
              ))}
            </div>

            {/* Add new tip */}
            <div className="flex gap-1.5">
              <input
                type="text"
                value={newTip}
                onChange={(e) => setNewTip(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddTip()}
                placeholder="나만의 꿀팁이나 방문 후기를 남겨주세요!"
                className="flex-1 bg-stone-100 border border-stone-300 focus:bg-white focus:border-[#8B1D24] text-xs px-3 py-1.5 rounded-xl outline-none"
              />
              <button
                onClick={handleAddTip}
                disabled={!newTip.trim()}
                className="bg-[#8B1D24] hover:bg-rose-900 disabled:opacity-40 text-white text-xs font-bold px-3 py-1.5 rounded-xl transition-all shrink-0 cursor-pointer"
              >
                등록
              </button>
            </div>
          </div>
        </div>

        {/* Footer Navigation Buttons */}
        <div className="p-4 bg-white border-t border-stone-200 flex gap-2 shrink-0">
          <a
            href={`https://map.kakao.com/link/to/${encodeURIComponent(store.name)},${store.lat},${store.lng}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 bg-yellow-400 hover:bg-yellow-500 text-stone-950 font-extrabold text-xs py-3 rounded-2xl text-center shadow-sm flex items-center justify-center gap-1 transition-all"
          >
            <span>카카오맵 길찾기 📍</span>
          </a>
          <a
            href={`https://map.naver.com/p/search/${encodeURIComponent(store.name)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs py-3 rounded-2xl text-center shadow-sm flex items-center justify-center gap-1 transition-all"
          >
            <span>네이버 지도 검색 🔍</span>
          </a>
        </div>
      </div>
    </div>
  );
};
