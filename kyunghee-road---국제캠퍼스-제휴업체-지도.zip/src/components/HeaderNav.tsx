import React from 'react';
import { Search, Sparkles, MapPin, X, Navigation, Award, MessageSquareHeart, Layers, List, Map as MapIcon, SlidersHorizontal, Download } from 'lucide-react';
import { Store, StoreType } from '../types';

interface HeaderNavProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: StoreType | 'all';
  setSelectedCategory: (cat: StoreType | 'all') => void;
  stores: Store[];
  filteredStores: Store[];
  onSelectStore: (store: Store) => void;
  onFocusGate: () => void;
  onOpenLadder: () => void;
  onOpenRank: (mode: 'popular' | 'discount' | 'distance') => void;
  onOpenSavings: () => void;
  onOpenFeedback: () => void;
  totalSavedAmount: number;
  isListView: boolean;
  setIsListView: (val: boolean) => void;
  onGetUserLocation: () => void;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  searchQuery,
  setSearchQuery,
  selectedCategory,
  setSelectedCategory,
  stores,
  filteredStores,
  onSelectStore,
  onFocusGate,
  onOpenLadder,
  onOpenRank,
  onOpenSavings,
  onOpenFeedback,
  totalSavedAmount,
  isListView,
  setIsListView,
  onGetUserLocation,
}) => {
  const [showSearchDropdown, setShowSearchDropdown] = React.useState(false);

  const searchResults = React.useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase();
    return stores.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        s.category.toLowerCase().includes(q) ||
        s.benefit.toLowerCase().includes(q) ||
        (s.tags && s.tags.some((t) => t.toLowerCase().includes(q))) ||
        (s.recommendedMenus && s.recommendedMenus.some((m) => m.toLowerCase().includes(q)))
    ).slice(0, 6);
  }, [searchQuery, stores]);

  const categoryCounts = React.useMemo(() => {
    return {
      all: stores.length,
      food: stores.filter((s) => s.type === 'food').length,
      pub: stores.filter((s) => s.type === 'pub').length,
      cafe: stores.filter((s) => s.type === 'cafe').length,
      life: stores.filter((s) => s.type === 'life').length,
    };
  }, [stores]);

  return (
    <header className="absolute top-3 left-3 right-3 sm:left-4 sm:top-4 z-40 max-w-md w-auto flex flex-col gap-2 pointer-events-none">
      {/* Top Banner Row */}
      <div className="flex gap-2 pointer-events-auto items-stretch">
        {/* Brand Title Card */}
        <div className="flex-1 bg-[#8B1D24] text-white px-3.5 py-2.5 rounded-2xl shadow-lg shadow-rose-950/20 flex flex-col justify-center border border-rose-800/40">
          <div className="flex items-center gap-2">
            <span className="text-xl leading-none">🦁</span>
            <div>
              <h1 className="font-extrabold text-[15px] tracking-tight leading-none text-white">
                KYUNGHEE ROAD
              </h1>
              <p className="text-[10px] text-rose-200 font-medium tracking-normal mt-0.5">
                국제캠퍼스 제휴업체 지도
              </p>
            </div>
          </div>
        </div>

        {/* '오늘 뭐 먹지?' 사다리 추천 버튼 */}
        <button
          id="btn-ladder-launcher"
          onClick={onOpenLadder}
          className="bg-white hover:bg-rose-50 text-[#8B1D24] border-2 border-[#8B1D24] rounded-2xl px-3 py-1.5 flex flex-col items-center justify-center shadow-md hover:shadow-lg transition-all transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer min-w-[105px]"
          title="오늘 뭐 먹을지 고민될 때 사다리 게임으로 제휴 맛집 추천받기"
        >
          <div className="flex items-center gap-1 font-extrabold text-[12px] whitespace-nowrap">
            <span>🎲 오늘 뭐 먹지?</span>
          </div>
          <span className="text-[9.5px] font-semibold text-rose-700/80 bg-rose-100/60 px-1.5 py-0.2 rounded-full mt-0.5">
            사다리 추천 🎯
          </span>
        </button>
      </div>

      {/* Sub Action Bar: 절약 배너 & 정문 위치 & 내 위치 */}
      <div className="flex gap-1.5 pointer-events-auto items-center">
        {/* 누적 제휴 절약 배너 */}
        <button
          id="btn-savings-banner"
          onClick={onOpenSavings}
          className="flex-1 bg-white/95 backdrop-blur-md border border-stone-200 text-stone-800 px-3 py-1.5 rounded-xl text-xs font-medium flex items-center justify-between shadow-sm hover:border-[#8B1D24] transition-all cursor-pointer group"
          title="경희대 학우 누적 혜택 장부 보기"
        >
          <div className="flex items-center gap-1.5">
            <span className="bg-[#8B1D24] text-white text-[9.5px] font-bold px-1.5 py-0.5 rounded-md">
              누적
            </span>
            <span className="text-stone-600 text-[11px]">학우 혜택</span>
          </div>
          <div className="text-[12px] font-bold text-[#8B1D24] group-hover:scale-105 transition-transform">
            {totalSavedAmount.toLocaleString()}원 절약! 🎉
          </div>
        </button>

        {/* 정문 위치 펄스 버튼 */}
        <button
          id="btn-gate-focus"
          onClick={onFocusGate}
          className="bg-white hover:bg-stone-50 border border-stone-300 text-stone-800 px-2.5 py-1.5 rounded-xl text-[11.5px] font-bold flex items-center gap-1 shadow-sm hover:border-stone-400 transition-all cursor-pointer whitespace-nowrap active:scale-95"
          title="경희대학교 국제캠퍼스 정문 위치로 이동"
        >
          <span>🏛️</span>
          <span>정문 위치</span>
        </button>

        {/* 단일 파일 다운로드 버튼 */}
        <a
          id="btn-download-single-html"
          href="/api/download"
          download="kyunghee_road_single.html"
          className="bg-white hover:bg-amber-50 border border-amber-300 text-amber-900 px-2.5 py-1.5 rounded-xl text-[11.5px] font-bold flex items-center gap-1 shadow-sm hover:border-amber-400 transition-all cursor-pointer whitespace-nowrap active:scale-95"
          title="단일 HTML 파일 다운로드 (인터넷/로컬 어디서나 바로 실행 가능)"
        >
          <Download className="w-3.5 h-3.5 text-amber-700" />
          <span>단일 파일 다운</span>
        </a>

        {/* 지도/목록 뷰 토글 (모바일 편의) */}
        <button
          id="btn-view-toggle"
          onClick={() => setIsListView(!isListView)}
          className={`p-1.5 rounded-xl border text-xs font-bold shadow-sm transition-all cursor-pointer sm:hidden ${
            isListView
              ? 'bg-[#8B1D24] text-white border-[#8B1D24]'
              : 'bg-white text-stone-700 border-stone-300 hover:bg-stone-50'
          }`}
          title={isListView ? '지도 보기' : '목록 보기'}
        >
          {isListView ? <MapIcon className="w-4 h-4" /> : <List className="w-4 h-4" />}
        </button>
      </div>

      {/* Search Input Bar with Autocomplete */}
      <div className="relative pointer-events-auto">
        <div className="bg-white/95 backdrop-blur-md rounded-xl p-1.5 shadow-md border border-stone-200 flex items-center gap-1.5">
          <Search className="w-4 h-4 text-stone-400 ml-1.5 shrink-0" />
          <input
            id="search-store-input"
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setShowSearchDropdown(true);
            }}
            onFocus={() => setShowSearchDropdown(true)}
            placeholder="식당, 카페, 헬스장, 메뉴 검색 (예: 돈들집, 라멘)"
            className="w-full text-xs font-medium text-stone-800 placeholder-stone-400 bg-transparent outline-none py-1 px-1"
          />
          {searchQuery && (
            <button
              onClick={() => {
                setSearchQuery('');
                setShowSearchDropdown(false);
              }}
              className="p-1 hover:bg-stone-100 rounded-full text-stone-400 hover:text-stone-600 transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            onClick={() => {
              if (searchResults.length > 0) {
                onSelectStore(searchResults[0]);
                setShowSearchDropdown(false);
              }
            }}
            className="bg-[#8B1D24] hover:bg-rose-900 text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm transition-all shrink-0 cursor-pointer"
          >
            검색
          </button>
        </div>

        {/* Autocomplete dropdown */}
        {showSearchDropdown && searchResults.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-1.5 bg-white/95 backdrop-blur-md rounded-xl shadow-xl border border-stone-200 max-h-64 overflow-y-auto z-50 p-1 divide-y divide-stone-100">
            {searchResults.map((store) => (
              <div
                key={store.id}
                onClick={() => {
                  onSelectStore(store);
                  setShowSearchDropdown(false);
                }}
                className="p-2 hover:bg-rose-50/80 rounded-lg cursor-pointer transition-colors flex items-center justify-between"
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-xs text-stone-900">{store.name}</span>
                    <span className="text-[10px] text-stone-500 bg-stone-100 px-1.5 py-0.2 rounded">
                      {store.category}
                    </span>
                  </div>
                  <div className="text-[11px] text-[#8B1D24] font-medium mt-0.5 truncate max-w-[260px]">
                    🎁 {store.benefit.split('\n')[0]}
                  </div>
                </div>
                <div className="text-[10px] text-stone-400 whitespace-nowrap ml-2">
                  정문 {store.distanceFromGateMeters}m
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Category Filter Chips Bar */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 pointer-events-auto scrollbar-none">
        <button
          id="filter-all"
          onClick={() => setSelectedCategory('all')}
          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold shadow-sm transition-all whitespace-nowrap cursor-pointer flex items-center gap-1 ${
            selectedCategory === 'all'
              ? 'bg-[#8B1D24] text-white shadow-rose-900/20'
              : 'bg-white/90 text-stone-700 border border-stone-200 hover:bg-stone-50'
          }`}
        >
          <span>전체</span>
          <span
            className={`text-[9.5px] px-1 rounded-full ${
              selectedCategory === 'all' ? 'bg-white/20 text-white' : 'bg-stone-100 text-stone-500'
            }`}
          >
            {categoryCounts.all}
          </span>
        </button>

        <button
          id="filter-food"
          onClick={() => setSelectedCategory('food')}
          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold shadow-sm transition-all whitespace-nowrap cursor-pointer flex items-center gap-1 ${
            selectedCategory === 'food'
              ? 'bg-[#8B1D24] text-white shadow-rose-900/20'
              : 'bg-white/90 text-stone-700 border border-stone-200 hover:bg-stone-50'
          }`}
        >
          <span>🍽️ 식당</span>
          <span
            className={`text-[9.5px] px-1 rounded-full ${
              selectedCategory === 'food' ? 'bg-white/20 text-white' : 'bg-stone-100 text-stone-500'
            }`}
          >
            {categoryCounts.food}
          </span>
        </button>

        <button
          id="filter-pub"
          onClick={() => setSelectedCategory('pub')}
          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold shadow-sm transition-all whitespace-nowrap cursor-pointer flex items-center gap-1 ${
            selectedCategory === 'pub'
              ? 'bg-blue-900 text-white shadow-blue-900/20'
              : 'bg-white/90 text-stone-700 border border-stone-200 hover:bg-stone-50'
          }`}
        >
          <span>🍺 주점</span>
          <span
            className={`text-[9.5px] px-1 rounded-full ${
              selectedCategory === 'pub' ? 'bg-white/20 text-white' : 'bg-stone-100 text-stone-500'
            }`}
          >
            {categoryCounts.pub}
          </span>
        </button>

        <button
          id="filter-cafe"
          onClick={() => setSelectedCategory('cafe')}
          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold shadow-sm transition-all whitespace-nowrap cursor-pointer flex items-center gap-1 ${
            selectedCategory === 'cafe'
              ? 'bg-amber-900 text-white shadow-amber-900/20'
              : 'bg-white/90 text-stone-700 border border-stone-200 hover:bg-stone-50'
          }`}
        >
          <span>☕ 카페/디저트</span>
          <span
            className={`text-[9.5px] px-1 rounded-full ${
              selectedCategory === 'cafe' ? 'bg-white/20 text-white' : 'bg-stone-100 text-stone-500'
            }`}
          >
            {categoryCounts.cafe}
          </span>
        </button>

        <button
          id="filter-life"
          onClick={() => setSelectedCategory('life')}
          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold shadow-sm transition-all whitespace-nowrap cursor-pointer flex items-center gap-1 ${
            selectedCategory === 'life'
              ? 'bg-emerald-800 text-white shadow-emerald-900/20'
              : 'bg-white/90 text-stone-700 border border-stone-200 hover:bg-stone-50'
          }`}
        >
          <span>💪 운동/라이프</span>
          <span
            className={`text-[9.5px] px-1 rounded-full ${
              selectedCategory === 'life' ? 'bg-white/20 text-white' : 'bg-stone-100 text-stone-500'
            }`}
          >
            {categoryCounts.life}
          </span>
        </button>
      </div>
    </header>
  );
};
