import React, { useState } from 'react';
import { Store } from '../types';
import { X, Flame, Percent, MapPin, ChevronRight, Star } from 'lucide-react';

interface RankModalProps {
  isOpen: boolean;
  onClose: () => void;
  stores: Store[];
  initialTab?: 'popular' | 'discount' | 'distance';
  onSelectStore: (store: Store) => void;
}

export const RankModal: React.FC<RankModalProps> = ({
  isOpen,
  onClose,
  stores,
  initialTab = 'popular',
  onSelectStore,
}) => {
  const [activeTab, setActiveTab] = useState<'popular' | 'discount' | 'distance'>(initialTab);

  if (!isOpen) return null;

  const sortedStores = [...stores].sort((a, b) => {
    if (activeTab === 'popular') {
      return (b.rating || 4.5) * 100 + (b.reviewCount || 50) - ((a.rating || 4.5) * 100 + (a.reviewCount || 50));
    } else if (activeTab === 'discount') {
      return b.discountScore - a.discountScore;
    } else {
      return (a.distanceFromGateMeters || 9999) - (b.distanceFromGateMeters || 9999);
    }
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl shadow-2xl border border-stone-200 max-w-md w-full overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="bg-[#8B1D24] text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xl">🏆</span>
            <div>
              <h3 className="font-extrabold text-base leading-tight">경희대 제휴 매장 순위</h3>
              <p className="text-[11px] text-rose-200">학우들이 가장 많이 찾고 아끼는 핫플</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Buttons */}
        <div className="flex border-b border-stone-200 bg-stone-50 p-1.5 gap-1.5">
          <button
            onClick={() => setActiveTab('popular')}
            className={`flex-1 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1 transition-all cursor-pointer ${
              activeTab === 'popular'
                ? 'bg-[#8B1D24] text-white shadow-sm'
                : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            <span>🔥 인기순</span>
          </button>
          <button
            onClick={() => setActiveTab('discount')}
            className={`flex-1 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1 transition-all cursor-pointer ${
              activeTab === 'discount'
                ? 'bg-[#8B1D24] text-white shadow-sm'
                : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
            }`}
          >
            <Percent className="w-3.5 h-3.5" />
            <span>💸 할인순</span>
          </button>
          <button
            onClick={() => setActiveTab('distance')}
            className={`flex-1 py-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1 transition-all cursor-pointer ${
              activeTab === 'distance'
                ? 'bg-[#8B1D24] text-white shadow-sm'
                : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-100'
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>🚶 가까운순</span>
          </button>
        </div>

        {/* List Content */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2 bg-stone-100/60 divide-y divide-transparent">
          {sortedStores.map((store, index) => {
            const isTop3 = index < 3;
            const rankBadgeColor =
              index === 0
                ? 'bg-amber-400 text-stone-900 ring-2 ring-amber-300'
                : index === 1
                ? 'bg-stone-300 text-stone-800'
                : index === 2
                ? 'bg-amber-700 text-white'
                : 'bg-stone-200 text-stone-600';

            return (
              <div
                key={store.id}
                onClick={() => {
                  onClose();
                  onSelectStore(store);
                }}
                className="bg-white hover:bg-rose-50/70 p-3 rounded-2xl border border-stone-200/80 shadow-sm flex items-center gap-3 cursor-pointer transition-all hover:border-rose-300 group"
              >
                {/* Rank Badge */}
                <div
                  className={`w-7 h-7 rounded-xl font-black text-xs flex items-center justify-center shrink-0 ${rankBadgeColor}`}
                >
                  {index + 1}
                </div>

                {/* Store Thumbnail */}
                <div className="w-12 h-12 rounded-xl overflow-hidden bg-stone-200 shrink-0">
                  <img
                    src={store.img}
                    alt={store.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src =
                        'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop&q=80';
                    }}
                  />
                </div>

                {/* Store Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-extrabold text-xs text-stone-900 truncate">
                      {store.name}
                    </h4>
                    <span className="text-[10px] text-stone-500 bg-stone-100 px-1.5 py-0.2 rounded shrink-0">
                      {store.category.split('/')[0]}
                    </span>
                  </div>

                  <div className="text-[11px] font-bold text-[#8B1D24] truncate mt-0.5">
                    🎁 {store.benefit.split('\n')[0]}
                  </div>

                  <div className="flex items-center gap-2 mt-1 text-[10.5px] text-stone-500">
                    <span className="flex items-center gap-0.5 text-amber-600 font-semibold">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      {store.rating || 4.8}
                    </span>
                    <span>•</span>
                    <span>정문 {store.distanceFromGateMeters}m</span>
                    {activeTab === 'discount' && (
                      <>
                        <span>•</span>
                        <span className="font-bold text-rose-700">
                          할인지수 {store.discountScore}점
                        </span>
                      </>
                    )}
                  </div>
                </div>

                {/* Arrow */}
                <ChevronRight className="w-4 h-4 text-stone-400 group-hover:text-rose-700 transition-colors shrink-0" />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
