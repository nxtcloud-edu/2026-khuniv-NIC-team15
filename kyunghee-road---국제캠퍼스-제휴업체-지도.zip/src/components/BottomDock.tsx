import React from 'react';
import { Flame, Percent, MessageSquareHeart, Wallet, Bot, Sparkles } from 'lucide-react';

interface BottomDockProps {
  onOpenRank: (mode: 'popular' | 'discount' | 'distance') => void;
  onOpenFeedback: () => void;
  onOpenSavings: () => void;
  onToggleChatbot: () => void;
  isChatOpen: boolean;
}

export const BottomDock: React.FC<BottomDockProps> = ({
  onOpenRank,
  onOpenFeedback,
  onOpenSavings,
  onToggleChatbot,
  isChatOpen,
}) => {
  return (
    <>
      {/* Bottom Left Quick Action Dock */}
      <div className="absolute bottom-4 left-3 sm:left-4 z-40 flex items-center gap-1.5 flex-wrap max-w-[calc(100vw-110px)] pointer-events-none">
        <div className="flex items-center gap-1.5 p-1 bg-white/90 backdrop-blur-md rounded-2xl shadow-lg border border-stone-200 pointer-events-auto">
          <button
            id="btn-dock-popular"
            onClick={() => onOpenRank('popular')}
            className="flex items-center gap-1 bg-white hover:bg-rose-50 text-stone-800 hover:text-[#8B1D24] px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all border border-stone-200 hover:border-rose-300 shadow-2xs cursor-pointer active:scale-95 whitespace-nowrap"
          >
            <span>🔥</span>
            <span>인기순</span>
          </button>

          <button
            id="btn-dock-discount"
            onClick={() => onOpenRank('discount')}
            className="flex items-center gap-1 bg-white hover:bg-rose-50 text-stone-800 hover:text-[#8B1D24] px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all border border-stone-200 hover:border-rose-300 shadow-2xs cursor-pointer active:scale-95 whitespace-nowrap"
          >
            <span>💸</span>
            <span>할인순</span>
          </button>

          <button
            id="btn-dock-feedback"
            onClick={onOpenFeedback}
            className="flex items-center gap-1 bg-stone-900 hover:bg-stone-800 text-white px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-2xs cursor-pointer active:scale-95 whitespace-nowrap"
          >
            <span>💡</span>
            <span>제휴 건의</span>
          </button>
        </div>
      </div>

      {/* Floating Action Button (AI Chatbot) on Bottom Right */}
      <div className="absolute bottom-4 right-3 sm:right-5 z-40 pointer-events-auto">
        <button
          id="btn-chatbot-fab"
          onClick={onToggleChatbot}
          className={`relative group w-14 h-14 sm:w-16 sm:h-16 rounded-full shadow-2xl transition-all duration-300 flex items-center justify-center cursor-pointer active:scale-95 ${
            isChatOpen
              ? 'bg-stone-900 text-white rotate-90 scale-105'
              : 'bg-[#8B1D24] hover:bg-rose-900 text-white hover:scale-108'
          }`}
          title="경희대 AI 제휴봇 열기"
        >
          {/* Subtle pulsating glow ring */}
          {!isChatOpen && (
            <span className="absolute -inset-1 rounded-full bg-[#8B1D24]/30 animate-pulse" />
          )}

          <div className="relative flex flex-col items-center justify-center">
            <span className="text-2xl sm:text-3xl leading-none select-none">
              {isChatOpen ? '✕' : '🤖'}
            </span>
          </div>

          {/* Tooltip badge */}
          {!isChatOpen && (
            <span className="absolute -top-2 -right-1 bg-yellow-400 text-stone-950 font-black text-[9px] px-1.5 py-0.5 rounded-full shadow border border-yellow-200 animate-bounce">
              AI봇
            </span>
          )}
        </button>
      </div>
    </>
  );
};
