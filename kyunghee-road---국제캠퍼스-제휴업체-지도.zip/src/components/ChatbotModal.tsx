import React, { useState, useRef, useEffect } from 'react';
import { Store, ChatMessage } from '../types';
import { X, Send, Bot, Sparkles, MapPin, Trash2, ArrowUpRight } from 'lucide-react';

interface ChatbotModalProps {
  isOpen: boolean;
  onClose: () => void;
  stores: Store[];
  onSelectStoreOnMap: (store: Store) => void;
}

const QUICK_PROMPTS = [
  '정문 도보 3분 이내 혼밥 맛집 추천해줘',
  '10명 이상 동아리 회식하기 좋은 고깃집',
  '카공 & 팀플하기 좋은 조용한 카페',
  '할인율 가장 높은 헬스장 / 필라테스',
  '분위기 좋은 감성 칵테일바 & 술집',
];

export const ChatbotModal: React.FC<ChatbotModalProps> = ({
  isOpen,
  onClose,
  stores,
  onSelectStoreOnMap,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      sender: 'bot',
      text: `안녕 학우야! 🦁 나는 경희대학교 국제캠퍼스 전용 **AI 제휴봇**이야.\n\n원하는 메뉴, 인원수, 위치(정문/영통역/서천동), 예산이나 목적을 편하게 말해줘! 딱 맞는 제휴 혜택과 매장을 추천해줄게. ✨`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [customKey, setCustomKey] = useState('');
  const [showKeyInput, setShowKeyInput] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputValue).trim();
    if (!query || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputValue('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: query,
          customApiKey: customKey.trim() || undefined,
        }),
      });

      if (!res.ok) {
        throw new Error('응답 실패');
      }

      const data = await res.json();
      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: data.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedStoreNames: data.suggestedStoreNames,
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      console.error('Chat error:', err);
      // Fallback
      const botMsg: ChatMessage = {
        id: `bot-err-${Date.now()}`,
        sender: 'bot',
        text: `잠시 통신에 지연이 발생했어요! 🦁 질문하신 내용과 관련된 제휴처를 찾아보실 수 있도록 상단 카테고리 필터나 검색창을 활용해 보세요!`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, botMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleStoreTagClick = (storeName: string) => {
    const found = stores.find((s) => s.name === storeName || storeName.includes(s.name) || s.name.includes(storeName));
    if (found) {
      onClose();
      onSelectStoreOnMap(found);
    }
  };

  const renderFormattedText = (text: string, suggestedStores?: string[]) => {
    return (
      <div className="space-y-1 leading-relaxed text-[12.5px] whitespace-pre-wrap">
        {text.split('\n').map((line, idx) => {
          return (
            <p key={idx} className={line.startsWith('•') || line.startsWith('✨') ? 'pl-1' : ''}>
              {line}
            </p>
          );
        })}

        {suggestedStores && suggestedStores.length > 0 && (
          <div className="flex flex-wrap gap-1.5 pt-2 mt-2 border-t border-stone-200/60">
            {suggestedStores.map((name) => (
              <button
                key={name}
                onClick={() => handleStoreTagClick(name)}
                className="bg-rose-50 hover:bg-[#8B1D24] text-[#8B1D24] hover:text-white border border-rose-200 px-2 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer shadow-xs"
              >
                <MapPin className="w-3 h-3 shrink-0" />
                <span>{name}</span>
                <ArrowUpRight className="w-3 h-3 opacity-70" />
              </button>
            ))}
          </div>
        )}
      </div>
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-24 right-4 sm:right-6 z-50 w-[min(92vw,390px)] h-[560px] max-h-[80vh] bg-white rounded-3xl shadow-2xl border border-stone-200 flex flex-col overflow-hidden animate-slideUp">
      {/* Header */}
      <div className="bg-[#8B1D24] text-white px-4 py-3.5 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-lg">
            🦁
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="font-extrabold text-sm leading-none">제휴봇 (경희대 AI)</h3>
              <span className="bg-yellow-400 text-stone-950 text-[9.5px] font-black px-1.5 py-0.2 rounded-full">
                Gemini 3.7
              </span>
            </div>
            <p className="text-[10.5px] text-rose-200 mt-0.5">국제캠퍼스 맞춤 제휴 추천 도우미</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setMessages([messages[0]])}
            className="p-1.5 rounded-full hover:bg-white/20 text-rose-200 hover:text-white transition-colors cursor-pointer"
            title="대화 내역 비우기"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-3.5 space-y-3 bg-stone-100/70">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[88%] p-3 rounded-2xl shadow-sm ${
                msg.sender === 'user'
                  ? 'bg-[#8B1D24] text-white rounded-tr-xs'
                  : 'bg-white text-stone-900 border border-stone-200/80 rounded-tl-xs'
              }`}
            >
              {renderFormattedText(msg.text, msg.suggestedStoreNames)}
            </div>
            <span className="text-[9.5px] text-stone-400 mt-1 px-1">{msg.timestamp}</span>
          </div>
        ))}

        {isLoading && (
          <div className="flex items-start gap-2">
            <div className="bg-white border border-stone-200 p-3 rounded-2xl rounded-tl-xs shadow-sm flex items-center gap-2">
              <span className="animate-spin text-sm">🦁</span>
              <span className="text-xs text-stone-600 font-semibold">
                제휴봇이 최적의 제휴 매장을 분석 중이에요...
              </span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts Carousel */}
      <div className="p-2 bg-stone-50 border-t border-stone-200 overflow-x-auto flex gap-1.5 scrollbar-none">
        {QUICK_PROMPTS.map((prompt, i) => (
          <button
            key={i}
            onClick={() => handleSendMessage(prompt)}
            disabled={isLoading}
            className="px-2.5 py-1 rounded-full bg-white hover:bg-rose-50 border border-stone-200 hover:border-rose-300 text-stone-700 hover:text-[#8B1D24] text-[11px] font-bold whitespace-nowrap transition-all shadow-2xs shrink-0 cursor-pointer disabled:opacity-50"
          >
            ⚡ {prompt}
          </button>
        ))}
      </div>

      {/* Chat Input */}
      <div className="p-2.5 bg-white border-t border-stone-200 flex items-center gap-2">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
          placeholder="예: 정문 근처 혼밥 라멘집 추천해줘"
          disabled={isLoading}
          className="flex-1 bg-stone-100 border border-stone-300 focus:border-[#8B1D24] focus:bg-white rounded-2xl px-3.5 py-2 text-xs text-stone-900 placeholder-stone-400 outline-none transition-all"
        />
        <button
          onClick={() => handleSendMessage()}
          disabled={!inputValue.trim() || isLoading}
          className="bg-[#8B1D24] hover:bg-rose-900 disabled:opacity-40 text-white p-2.5 rounded-2xl shadow-sm transition-all shrink-0 cursor-pointer"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
