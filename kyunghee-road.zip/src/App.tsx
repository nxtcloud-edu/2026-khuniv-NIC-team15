import React, { useState, useEffect } from 'react';
import { AFFILIATE_STORES } from './data/stores';
import { FilterType, Store, StudentProfile } from './types';
import { HeaderNav } from './components/HeaderNav';
import { MapArea } from './components/MapArea';
import { BottomDock } from './components/BottomDock';
import { LadderModal } from './components/LadderModal';
import { RankingModal } from './components/RankingModal';
import { ChatbotModal } from './components/ChatbotModal';
import { FeedbackModal } from './components/FeedbackModal';
import { SavingsCalculatorModal } from './components/SavingsCalculatorModal';
import { StoreDetailModal } from './components/StoreDetailModal';
import { StudentProfileModal } from './components/StudentProfileModal';

export default function App() {
  const [stores] = useState<Store[]>(AFFILIATE_STORES);
  const [currentFilter, setCurrentFilter] = useState<FilterType>('all');
  const [selectedStore, setSelectedStore] = useState<Store | null>(null);
  const [isGateFocused, setIsGateFocused] = useState<boolean>(false);

  // Student Profile state
  const [studentProfile, setStudentProfile] = useState<StudentProfile | null>(() => {
    try {
      const saved = localStorage.getItem('khu_student_profile');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    return null;
  });

  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('khu_student_profile');
      return !saved; // Open modal on initial launch if profile is not set
    } catch {
      return true;
    }
  });
  const [isInitialSetup, setIsInitialSetup] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('khu_student_profile');
      return !saved;
    } catch {
      return true;
    }
  });

  // Modals state
  const [isLadderOpen, setIsLadderOpen] = useState(false);
  const [isRankingOpen, setIsRankingOpen] = useState(false);
  const [rankingTab, setRankingTab] = useState<'popular' | 'discount'>('popular');
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);
  const [isSavingsOpen, setIsSavingsOpen] = useState(false);
  const [detailStore, setDetailStore] = useState<Store | null>(null);

  // Filter count
  const filteredCount = stores.filter(
    (s) => currentFilter === 'all' || s.type === currentFilter
  ).length;

  const handleSaveProfile = (profile: StudentProfile) => {
    setStudentProfile(profile);
    try {
      localStorage.setItem('khu_student_profile', JSON.stringify(profile));
    } catch {
      // ignore
    }
    setIsInitialSetup(false);
  };

  const handleOpenRank = (tab: 'popular' | 'discount') => {
    setRankingTab(tab);
    setIsRankingOpen(true);
  };

  const handleSelectStoreFromAnywhere = (store: Store) => {
    // If filtered out, switch filter to 'all' so marker is visible
    if (currentFilter !== 'all' && store.type !== currentFilter) {
      setCurrentFilter('all');
    }
    setSelectedStore(store);
  };

  const handleFocusGate = () => {
    setIsGateFocused(true);
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-gray-100 font-sans">
      {/* 1. Header Navigation & Filter Bar */}
      <HeaderNav
        currentFilter={currentFilter}
        onFilterChange={setCurrentFilter}
        onSearch={(query) => {
          // If search term matches exactly or partially, keep filter responsive
        }}
        onSelectStore={handleSelectStoreFromAnywhere}
        onFocusGate={handleFocusGate}
        onOpenLadder={() => setIsLadderOpen(true)}
        onOpenSavings={() => setIsSavingsOpen(true)}
        onOpenProfile={() => {
          setIsInitialSetup(false);
          setIsProfileModalOpen(true);
        }}
        studentProfile={studentProfile}
        stores={stores}
        filteredCount={filteredCount}
      />

      {/* 2. Interactive Map */}
      <main className="w-full h-full">
        <MapArea
          stores={stores}
          currentFilter={currentFilter}
          selectedStore={selectedStore}
          onSelectStore={setSelectedStore}
          onOpenDetailModal={(store) => setDetailStore(store)}
          isGateFocused={isGateFocused}
          onGateFocusReset={() => setIsGateFocused(false)}
        />
      </main>

      {/* 3. Bottom Action Dock & AI Chatbot FAB */}
      <BottomDock
        onOpenRank={handleOpenRank}
        onOpenFeedback={() => setIsFeedbackOpen(true)}
        onToggleChatbot={() => setIsChatbotOpen(!isChatbotOpen)}
        isChatOpen={isChatbotOpen}
      />

      {/* 4. Modals */}
      {/* Student Profile Input Modal */}
      <StudentProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        currentProfile={studentProfile}
        onSaveProfile={handleSaveProfile}
        isInitialSetup={isInitialSetup}
      />

      <LadderModal
        isOpen={isLadderOpen}
        onClose={() => setIsLadderOpen(false)}
        stores={stores}
        onSelectStore={handleSelectStoreFromAnywhere}
      />

      <RankingModal
        isOpen={isRankingOpen}
        onClose={() => setIsRankingOpen(false)}
        stores={stores}
        onSelectStore={handleSelectStoreFromAnywhere}
        initialTab={rankingTab}
      />

      <ChatbotModal
        isOpen={isChatbotOpen}
        onClose={() => setIsChatbotOpen(false)}
        stores={stores}
        onSelectStore={handleSelectStoreFromAnywhere}
        studentProfile={studentProfile}
      />

      <FeedbackModal
        isOpen={isFeedbackOpen}
        onClose={() => setIsFeedbackOpen(false)}
      />

      <SavingsCalculatorModal
        isOpen={isSavingsOpen}
        onClose={() => setIsSavingsOpen(false)}
      />

      <StoreDetailModal
        store={detailStore}
        onClose={() => setDetailStore(null)}
      />
    </div>
  );
}
