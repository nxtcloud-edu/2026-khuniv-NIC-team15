import React, { useState } from 'react';
import { Store, StoreCategory } from '../types';
import { KHU_GATE_LOCATION } from '../data/stores';
import { X, Flame, Percent, MapPin, Sparkles, Navigation } from 'lucide-react';

interface RankingModalProps {
  isOpen: boolean;
  onClose: () => void;
  stores: Store[];
  onSelectStore: (store: Store) => void;
  initialTab?: 'popular' | 'discount' | 'nearest';
}

// Distance helper in meters
function getDistanceFromGate(lat: number, lng: number): number {
  const R = 6371e3; // meters
  const phi1 = (KHU_GATE_LOCATION.lat * Math.PI) / 180;
  const phi2 = (lat * Math.PI) / 180;
  const deltaPhi = ((lat - KHU_GATE_LOCATION.lat) * Math.PI) / 180;
  const deltaLambda = ((lng - KHU_GATE_LOCATION.lng) * Math.PI) / 180;

  const a =
    Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return Math.round(R * c);
}

export const RankingModal: React.FC<RankingModalProps> = ({
  isOpen,
  onClose,
  stores,
  onSelectStore,
  initialTab = 'popular',
}) => {
  const [activeTab, setActiveTab] = useState<'popular' | 'discount' | 'nearest'>(initialTab);
  const [categoryFilter, setCategoryFilter] = useState<'all' | StoreCategory>('all');

  if (!isOpen) return null;

  // Filter and sort stores
  let filtered = stores.filter((s) => categoryFilter === 'all' || s.type === categoryFilter);

  if (activeTab === 'popular') {
    filtered = [...filtered].sort((a, b) => (b.popularScore || 0) - (a.popularScore || 0));
  } else if (activeTab === 'discount') {
    filtered = [...filtered].sort((a, b) => b.discountScore - a.discountScore);
  } else if (activeTab === 'nearest') {
    filtered = [...filtered].sort((a, b) => {
      const distA = getDistanceFromGate(a.lat, a.lng);
      const distB = getDistanceFromGate(b.lat, b.lng);
      return distA - distB;
    });
  }

  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border border-gray-100 w-full max-w-[440px] max-h-[85vh] overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="bg-[#8B1D24] text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xl">🏆</span>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base leading-tight">
                경희대 제휴업체 랭킹
              </h3>
              <p className="text-[11px] text-white/80">학우들이 가장 많이 찾는 제휴 혜택 순위</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-white/20 rounded-full transition-colors text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="grid grid-cols-3 bg-gray-100 p-1.5 gap-1 border-b border-gray-200 text-xs font-extrabold">
          <button
            onClick={() => setActiveTab('popular')}
            className={`py-2 rounded-xl flex items-center justify-center gap-1 transition-all ${
              activeTab === 'popular'
                ? 'bg-white text-[#8B1D24] shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            <span>🔥 인기순</span>
          </button>
          <button
            onClick={() => setActiveTab('discount')}
            className={`py-2 rounded-xl flex items-center justify-center gap-1 transition-all ${
              activeTab === 'discount'
                ? 'bg-white text-[#8B1D24] shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Percent className="w-3.5 h-3.5" />
            <span>💸 할인순</span>
          </button>
          <button
            onClick={() => setActiveTab('nearest')}
            className={`py-2 rounded-xl flex items-center justify-center gap-1 transition-all ${
              activeTab === 'nearest'
                ? 'bg-white text-[#8B1D24] shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <Navigation className="w-3.5 h-3.5" />
            <span>📍 정문거리순</span>
          </button>
        </div>

        {/* Category Pills */}
        <div className="px-4 py-2 bg-gray-50 flex gap-1.5 overflow-x-auto no-scrollbar border-b border-gray-100">
          {(
            [
              { id: 'all', label: '전체' },
              { id: 'food', label: '🍽️ 식당' },
              { id: 'pub', label: '🍺 주점' },
              { id: 'cafe', label: '☕ 카페' },
              { id: 'life', label: '💪 라이프' },
            ] as const
          ).map((cat) => (
            <button
              key={cat.id}
              onClick={() => setCategoryFilter(cat.id)}
              className={`px-2.5 py-1 text-[11px] font-bold rounded-lg whitespace-nowrap transition-all ${
                categoryFilter === cat.id
                  ? 'bg-[#8B1D24] text-white shadow-xs'
                  : 'bg-white text-gray-600 hover:bg-gray-200 border border-gray-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* List Body */}
        <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-2 bg-gray-50">
          {filtered.map((store, index) => {
            const dist = getDistanceFromGate(store.lat, store.lng);
            const isTop3 = index < 3;
            const rankBadgeColor =
              index === 0
                ? 'bg-yellow-400 text-yellow-950 ring-2 ring-yellow-300'
                : index === 1
                ? 'bg-slate-300 text-slate-800 ring-2 ring-slate-200'
                : index === 2
                ? 'bg-amber-600 text-white ring-2 ring-amber-400'
                : 'bg-gray-100 text-gray-600';

            return (
              <div
                key={store.id}
                onClick={() => {
                  onClose();
                  onSelectStore(store);
                }}
                className="bg-white hover:bg-red-50/50 p-3 rounded-2xl border border-gray-200/90 shadow-xs hover:shadow-md hover:border-[#8B1D24]/50 cursor-pointer transition-all flex items-center gap-3 group"
              >
                {/* Rank number badge */}
                <div
                  className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-black shrink-0 ${rankBadgeColor}`}
                >
                  {index + 1}
                </div>

                {/* Store image */}
                <img
                  src={store.img}
                  alt={store.name}
                  className="w-12 h-12 rounded-xl object-cover shrink-0 border border-gray-100"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src =
                      'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=500&auto=format&fit=crop&q=60';
                  }}
                />

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <h4 className="text-xs sm:text-sm font-extrabold text-gray-900 truncate group-hover:text-[#8B1D24] transition-colors">
                      {store.name}
                    </h4>
                    <span className="text-[10px] text-gray-500 font-medium shrink-0">
                      {store.category.split('/')[0]}
                    </span>
                  </div>

                  <p className="text-[11px] text-[#8B1D24] font-bold truncate mt-0.5">
                    🎁 {store.benefit.split('\n')[0]}
                  </p>

                  <div className="flex items-center gap-2 mt-1 text-[10px] text-gray-500 font-medium">
                    <span className="flex items-center gap-0.5 text-gray-600">
                      <MapPin className="w-3 h-3 text-[#8B1D24]" />
                      정문에서 {dist > 1000 ? `${(dist / 1000).toFixed(1)}km` : `${dist}m`}
                    </span>
                    <span>•</span>
                    <span className="text-emerald-700 font-bold">
                      {store.estimatedSaving || '상시 할인'}
                    </span>
                  </div>
                </div>

                {/* Jump Button */}
                <button className="px-2.5 py-1.5 bg-gray-100 group-hover:bg-[#8B1D24] text-gray-600 group-hover:text-white rounded-xl text-[11px] font-bold shrink-0 transition-colors">
                  이동
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
