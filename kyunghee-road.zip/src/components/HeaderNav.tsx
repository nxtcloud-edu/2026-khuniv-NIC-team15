import React, { useState } from 'react';
import { FilterType, Store, StudentProfile } from '../types';
import { Search, MapPin, Sparkles, Trophy, MessageSquareText, Calculator, X, UserCircle, Edit3 } from 'lucide-react';

interface HeaderNavProps {
  currentFilter: FilterType;
  onFilterChange: (filter: FilterType) => void;
  onSearch: (query: string) => void;
  onSelectStore: (store: Store) => void;
  onFocusGate: () => void;
  onOpenLadder: () => void;
  onOpenSavings: () => void;
  onOpenProfile: () => void;
  studentProfile: StudentProfile | null;
  stores: Store[];
  filteredCount: number;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  currentFilter,
  onFilterChange,
  onSearch,
  onSelectStore,
  onFocusGate,
  onOpenLadder,
  onOpenSavings,
  onOpenProfile,
  studentProfile,
  stores,
  filteredCount,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchTerm(val);
    onSearch(val);
  };

  const handleClearSearch = () => {
    setSearchTerm('');
    onSearch('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const match = stores.find(
        (s) =>
          s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          s.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
          s.desc.toLowerCase().includes(searchTerm.toLowerCase()) ||
          s.benefit.toLowerCase().includes(searchTerm.toLowerCase())
      );
      if (match) {
        onSelectStore(match);
        setIsSearchFocused(false);
      }
    }
  };

  const searchSuggestions = searchTerm.trim()
    ? stores.filter(
        (s) =>
          s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          s.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
          s.tags?.some((t) => t.toLowerCase().includes(searchTerm.toLowerCase()))
      ).slice(0, 5)
    : [];

  const filterButtons: { type: FilterType; label: string; icon: string }[] = [
    { type: 'all', label: '전체', icon: '🌟' },
    { type: 'food', label: '식당', icon: '🍽️' },
    { type: 'pub', label: '주점', icon: '🍺' },
    { type: 'cafe', label: '카페/디저트', icon: '☕' },
    { type: 'life', label: '운동/라이프', icon: '💪' },
  ];

  return (
    <header className="absolute top-3 sm:top-4 left-3 sm:left-4 z-[1000] flex flex-col gap-2 w-[calc(100vw-24px)] sm:w-[430px] max-w-[94vw] pointer-events-auto">
      {/* Top row: Brand & Ladder Button */}
      <div className="flex gap-2 items-stretch">
        <div className="flex-1 bg-[#8B1D24] text-white px-3.5 py-2.5 rounded-2xl shadow-lg border border-red-950/20 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-white/15 flex items-center justify-center text-lg shadow-inner">
              🦁
            </div>
            <div>
              <div className="flex items-center gap-1.5 leading-none">
                <span className="font-extrabold tracking-tight text-[15px] sm:text-[16px]">KYUNGHEE ROAD</span>
                <span className="text-[10px] bg-yellow-400 text-red-950 font-black px-1.5 py-0.5 rounded">국제캠</span>
              </div>
              <p className="text-[11px] text-white/80 font-medium mt-0.5">
                경희대학교 제휴업체 혜택 지도
              </p>
            </div>
          </div>
        </div>

        {/* '오늘 뭐 먹지?' 사다리 추천 버튼 */}
        <button
          id="ladder-button"
          onClick={onOpenLadder}
          className="bg-white hover:bg-red-50 text-[#8B1D24] border-[1.5px] border-[#8B1D24] rounded-2xl px-3 py-2 text-xs font-bold flex flex-col items-center justify-center gap-0.5 shadow-md hover:shadow-lg transition-all transform hover:-translate-y-0.5 shrink-0 active:scale-95 cursor-pointer"
          title="오늘 뭐 먹지? 사다리 타기로 식당 고르기"
        >
          <span className="flex items-center gap-1 text-[12px] font-extrabold">
            🎲 오늘 뭐 먹지?
          </span>
          <span className="text-[10px] text-[#8B1D24]/80 font-semibold">사다리 추천 🎯</span>
        </button>
      </div>

      {/* Student Profile Quick Bar */}
      <div className="bg-white/95 backdrop-blur-sm border border-gray-200/90 rounded-2xl p-2 px-3 shadow-sm flex items-center justify-between gap-2 hover:border-[#8B1D24]/30 transition-all">
        <div
          onClick={onOpenProfile}
          className="flex items-center gap-2 min-w-0 cursor-pointer group flex-1"
          title="학생 정보 확인 및 수정"
        >
          <div className="w-6 h-6 rounded-full bg-red-100 text-[#8B1D24] flex items-center justify-center text-xs font-black shrink-0 group-hover:bg-[#8B1D24] group-hover:text-white transition-colors">
            🦁
          </div>
          <div className="truncate">
            <div className="flex items-center gap-1.5 leading-tight">
              <span className="text-[11px] font-black bg-[#8B1D24] text-white px-1.5 py-0.5 rounded-sm shrink-0">
                {studentProfile ? studentProfile.college : '단과대 미등록'}
              </span>
              <span className="text-xs font-black text-gray-800 truncate group-hover:text-[#8B1D24] transition-colors">
                {studentProfile ? `${studentProfile.name} 학우님` : '학우 정보 등록하기'}
              </span>
            </div>
          </div>
        </div>

        <button
          id="edit-profile-btn"
          onClick={onOpenProfile}
          className="text-[11px] font-bold text-gray-500 hover:text-[#8B1D24] bg-gray-100 hover:bg-red-50 px-2 py-1 rounded-lg flex items-center gap-1 transition-all shrink-0 cursor-pointer"
          title="학생 정보 수정"
        >
          <Edit3 className="w-3 h-3" />
          <span>{studentProfile ? '수정' : '등록'}</span>
        </button>
      </div>

      {/* Sub row: Cumulative savings & Single Gate Locator */}
      <div className="flex gap-2 items-center">
        <div
          onClick={onOpenSavings}
          className="flex-1 bg-white/95 backdrop-blur-sm border border-gray-200/90 text-gray-800 px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center justify-between shadow-sm hover:border-[#8B1D24]/40 hover:bg-white cursor-pointer transition-all group"
          title="학우 혜택 계산기 열기"
        >
          <div className="flex items-center gap-1.5">
            <span className="bg-[#8B1D24] text-white text-[10px] font-bold px-1.5 py-0.5 rounded">누적</span>
            <span className="text-gray-600 group-hover:text-gray-900">학우 혜택 절약</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-[13px] font-black text-[#8B1D24]">33,500원+</span>
            <Calculator className="w-3.5 h-3.5 text-[#8B1D24] group-hover:scale-110 transition-transform" />
          </div>
        </div>

        {/* 단 1개의 정문 위치 버튼 */}
        <button
          id="gate-locator-button"
          onClick={onFocusGate}
          className="bg-white hover:bg-gray-100 text-gray-800 border border-gray-300 px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1.5 shadow-sm hover:border-gray-400 transition-all shrink-0 active:scale-95"
          title="경희대 국제캠퍼스 정문(덕영대로) 위치로 지도 이동"
        >
          <span className="text-[13px]">🏛️</span>
          <span>정문 위치</span>
        </button>
      </div>

      {/* Search Input Box */}
      <div className="relative">
        <div className="bg-white rounded-xl shadow-md border border-gray-200/90 flex items-center px-2.5 py-1.5 gap-2 focus-within:ring-2 focus-within:ring-[#8B1D24]/30 focus-within:border-[#8B1D24] transition-all">
          <Search className="w-4 h-4 text-gray-400 shrink-0" />
          <input
            id="search-input"
            type="text"
            value={searchTerm}
            onChange={handleInputChange}
            onFocus={() => setIsSearchFocused(true)}
            onKeyDown={handleKeyDown}
            placeholder="식당, 카페, 헬스장, 혜택 검색 (예: 라멘, 할인)"
            className="w-full text-xs sm:text-sm bg-transparent outline-none text-gray-800 placeholder-gray-400 font-medium"
          />
          {searchTerm && (
            <button
              onClick={handleClearSearch}
              className="p-1 hover:bg-gray-100 rounded-full text-gray-400 hover:text-gray-600"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            onClick={() => {
              const match = stores.find(
                (s) =>
                  s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                  s.category.toLowerCase().includes(searchTerm.toLowerCase())
              );
              if (match) onSelectStore(match);
            }}
            className="bg-[#8B1D24] hover:bg-[#72151b] text-white px-2.5 py-1 rounded-lg text-xs font-bold shrink-0 transition-colors shadow-sm"
          >
            검색
          </button>
        </div>

        {/* Autocomplete suggestion dropdown */}
        {isSearchFocused && searchSuggestions.length > 0 && (
          <div className="absolute top-full mt-1.5 left-0 right-0 bg-white rounded-xl shadow-xl border border-gray-200 overflow-hidden z-50 divide-y divide-gray-100">
            {searchSuggestions.map((store) => (
              <div
                key={store.id}
                onClick={() => {
                  onSelectStore(store);
                  setIsSearchFocused(false);
                  setSearchTerm(store.name);
                }}
                className="p-2.5 hover:bg-red-50/70 cursor-pointer flex items-center justify-between transition-colors"
              >
                <div className="flex items-center gap-2">
                  <span className="text-sm">
                    {store.type === 'food' ? '🍽️' : store.type === 'pub' ? '🍺' : store.type === 'cafe' ? '☕' : '💪'}
                  </span>
                  <div>
                    <div className="text-xs font-bold text-gray-900">{store.name}</div>
                    <div className="text-[10px] text-gray-500">{store.category}</div>
                  </div>
                </div>
                <div className="text-[10px] text-[#8B1D24] font-semibold truncate max-w-[140px]">
                  {store.benefit.split('\n')[0]}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Category Filter Bar */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar select-none">
        {filterButtons.map((btn) => {
          const isActive = currentFilter === btn.type;
          return (
            <button
              key={btn.type}
              id={`filter-btn-${btn.type}`}
              onClick={() => onFilterChange(btn.type)}
              className={`px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 whitespace-nowrap shadow-sm transition-all ${
                isActive
                  ? 'bg-[#8B1D24] text-white shadow-red-950/20 scale-[1.02]'
                  : 'bg-white/95 hover:bg-white text-gray-700 hover:text-gray-900 border border-gray-200'
              }`}
            >
              <span>{btn.icon}</span>
              <span>{btn.label}</span>
              {btn.type === currentFilter && (
                <span className="bg-white/20 text-white text-[9px] px-1.5 py-0.2 rounded-full ml-0.5">
                  {filteredCount}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </header>
  );
};
